from pydantic import BaseModel, EmailStr, Field
from typing import List, Optional
from datetime import datetime
from fastapi import Query

class User(BaseModel):
    email: str
    password: str

class RegisterUser(BaseModel):
    name: str
    email: EmailStr
    password: str
    pais_id: int
    departamento_id: int
    terms_accepted_at: Optional[datetime] = None
    is_adult: bool = True

class UpdateUser(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    pais_id: Optional[int] = None
    departamento_id: Optional[int] = None
    fcm_token: Optional[str] = None
    telefono: Optional[str] = None
    idioma: Optional[str] = None
    notificaciones_activas: Optional[bool] = None
    app_version: Optional[str] = None
    plataforma: Optional[str] = None
    avatar_url: Optional[str] = None
    terms_accepted_at: Optional[datetime] = None
    is_adult: Optional[bool] = None

class JugadaCreate(BaseModel):
    numeros: List[int]
    user_id: str
    # Identidad canónica de la lotería. Es obligatoria en la práctica cuando
    # varias loterías/países comparten la misma route (Euromillions, EuroDreams, etc.).
    loteria_id: Optional[int] = None
    loteria_route: Optional[str] = None
    fecha_sorteo: Optional[str] = None
    fecha: Optional[str] = None

class JugadaUpdate(BaseModel):
    numeros: List[int]
    user_id: str
    loteria_id: Optional[int] = None
    loteria_route: Optional[str] = None

class JugadaOut(BaseModel):
    id: int
    user_id: int
    loteria_id: Optional[int] = None
    loteria_route: Optional[str] = None
    numeros: List[int]
    fecha_sorteo: Optional[str] = None
    fecha_guardado: Optional[datetime] = None
    expira: Optional[datetime] = None

class TransactionRequest(BaseModel):
    amount: float
    currency: str
    email: str
    name: str
    reference: str
    description: str = "Pago desde app"

class ForgotPasswordRequest(BaseModel):
    email: EmailStr

class PublicidadCreate(BaseModel):
    titulo: str
    descripcion: str
    categoria_id: int
    pais_id: int
    departamento_id: int
    ciudad_id: Optional[int] = None
    imagen_url: Optional[str] = None
    telefono: Optional[str] = None
    facebook_url: Optional[str] = None
    instagram_url: Optional[str] = None
    whatsapp_url: Optional[str] = None
    tiktok_url: Optional[str] = None
    pagina_url: Optional[str] = None
    direccion: Optional[str] = None
    es_24_7: Optional[bool] = False
    hora_apertura: Optional[str] = None
    hora_cierre: Optional[str] = None
    dias_atencion: Optional[str] = None
    estado_texto: Optional[str] = None

class ResetPasswordWithCodeRequest(BaseModel):
    email: EmailStr
    code: str
    new_password: str

class VerifyResetCodeRequest(BaseModel):
    email: EmailStr
    code: str

class VerifyEmailCodeRequest(BaseModel):
    email: EmailStr
    code: str

class CommentCreate(BaseModel):
    content: str = Field(..., min_length=1, max_length=300, description="Contenido entre 1 y 300 caracteres")
    parent_id: Optional[int] = None

class CommentResponse(BaseModel):
    id: int
    post_id: int
    user_id: int
    user_name: str
    content: str
    status: str = "active"
    moderation_reason: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    parent_id: Optional[int] = None

class CommentReportResponse(BaseModel):
    comment_id: int
    created: bool

class PostCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=100, description="Título del post entre 1 y 100 caracteres")
    content: str = Field(..., min_length=1, max_length=500, description="Contenido del post entre 1 y 500 caracteres")

class PostResponse(BaseModel):
    id: int
    title: str
    content: str
    user_id: int
    user_name: str
    created_at: datetime
    comments_count: int = 0

class LoteriaOut(BaseModel):
    id: int
    nombre: str
    tipo: Optional[str] = None
    pais_id: int
    proximo_sorteo: Optional[str] = None
    ultimo_sorteo: Optional[str] = None
    route: Optional[str] = None
    max_seleccion: Optional[int] = None
    max_balotas_blancas: Optional[int] = None
    max_balotas_rojas: Optional[int] = None
    superbalota_nombre: Optional[str] = None
    has_revancha: Optional[bool] = None
    total_balotas_sorteo: Optional[int] = None
    tiene_complementario: Optional[bool] = None
    tiene_reintegro: Optional[bool] = None
    jackpot: Optional[str] = None

class PublicidadQuery:
    def __init__(
        self,
        pais_id: Optional[int] = Query(None, description="Filtrar por país ID"),
        departamento_id: Optional[int] = Query(None, description="Filtrar por departamento ID"),
        ciudad_id: Optional[int] = Query(None, description="Filtrar por ciudad ID"),
        categoria_id: Optional[int] = Query(None, description="Filtrar por categoría ID"),
        titulo: Optional[str] = Query(None, description="Filtrar por título (coincidencia parcial, case-insensitive)"),
        limit: int = Query(20, ge=1, le=100, description="Número máximo de resultados por página"),
        offset: int = Query(0, ge=0, description="Offset para paginación")
    ):
        self.pais_id = pais_id
        self.departamento_id = departamento_id
        self.ciudad_id = ciudad_id
        self.categoria_id = categoria_id
        self.titulo = titulo
        self.limit = limit
        self.offset = offset

class RefreshTokenRequest(BaseModel):
    refresh_token: str

class FCMTokenUpdate(BaseModel):
    user_id: int
    fcm_token: str

class SocialLoginRequest(BaseModel):
    provider: str
    token: str

class SubscriptionConfirmRequest(BaseModel):
    user_id: Optional[int] = None
    product_id: str
    purchase_token: Optional[str] = None
    order_id: Optional[str] = None
    status: Optional[str] = "active"

