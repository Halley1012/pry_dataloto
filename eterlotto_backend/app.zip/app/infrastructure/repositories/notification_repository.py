from typing import List, Optional, Dict, Any
from datetime import datetime
import json

from app.domain.ports import NotificationRepositoryPort
from app.infrastructure import db_connection


class PostgresNotificationRepository(NotificationRepositoryPort):
    @staticmethod
    def _decode_message_params(value: Any) -> Dict[str, Any]:
        """Devuelve JSONB siempre como ``dict`` para la capa de aplicación."""
        current = value

        for _ in range(4):
            if current is None:
                return {}
            if isinstance(current, dict):
                return dict(current)
            if isinstance(current, (bytes, bytearray, memoryview)):
                try:
                    current = bytes(current).decode("utf-8")
                    continue
                except (UnicodeDecodeError, ValueError):
                    return {}
            if isinstance(current, str):
                raw = current.strip()
                if not raw:
                    return {}
                try:
                    current = json.loads(raw)
                    continue
                except (TypeError, ValueError, json.JSONDecodeError):
                    return {}
            try:
                mapped = dict(current)
            except (TypeError, ValueError):
                return {}
            return mapped if isinstance(mapped, dict) else {}

        return dict(current) if isinstance(current, dict) else {}

    async def _ensure_schema(self, conn) -> None:
        """Compatibilidad incremental sin depender de un despliegue de migración previo."""
        await conn.execute("""
            ALTER TABLE notificaciones
                ADD COLUMN IF NOT EXISTS message_key VARCHAR(120),
                ADD COLUMN IF NOT EXISTS message_params JSONB NOT NULL DEFAULT '{}'::jsonb;

            CREATE TABLE IF NOT EXISTS notification_user_state (
                notification_id INTEGER NOT NULL REFERENCES notificaciones(id) ON DELETE CASCADE,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                leido BOOLEAN NOT NULL DEFAULT FALSE,
                eliminado BOOLEAN NOT NULL DEFAULT FALSE,
                updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (notification_id, user_id)
            );
            CREATE INDEX IF NOT EXISTS idx_notification_user_state_visible
                ON notification_user_state (user_id, eliminado, notification_id);
        """)

    async def _ensure_user_state_table(self, conn) -> None:
        await self._ensure_schema(conn)

    async def create_notification(
        self,
        loteria_id: Optional[int],
        fecha_sorteo: Optional[datetime],
        mensaje: str,
        tipo: str,
        user_id: Optional[int] = None,
        message_key: Optional[str] = None,
        message_params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        pool = db_connection.get_pool()
        async with pool.acquire() as conn:
            await self._ensure_schema(conn)
            row = await conn.fetchrow(
                """
                INSERT INTO notificaciones
                    (usuario_id, loteria_id, fecha_sorteo, mensaje, tipo, leido,
                     message_key, message_params, created_at)
                VALUES ($1, $2, $3, $4, $5, FALSE, $6, $7::jsonb, CURRENT_TIMESTAMP)
                ON CONFLICT DO NOTHING
                RETURNING id, usuario_id, loteria_id, fecha_sorteo, mensaje, tipo,
                          message_key, message_params, created_at
                """,
                user_id,
                loteria_id,
                fecha_sorteo,
                mensaje,
                tipo,
                message_key,
                json.dumps(message_params or {}, ensure_ascii=False),
            )

            if row is None:
                return {
                    "success": True,
                    "created": False,
                    "duplicate": True,
                    "message": "Notificación ya existente",
                    "notification": None,
                }

            return {
                "success": True,
                "created": True,
                "duplicate": False,
                "message": "Notificación creada",
                "notification": dict(row),
            }

    async def list_push_targets(
        self,
        loteria_id: Optional[int],
        user_id: Optional[int] = None,
        fecha_sorteo: Optional[datetime] = None,
    ) -> List[Dict[str, Any]]:
        pool = db_connection.get_pool()
        async with pool.acquire() as conn:
            if user_id is not None:
                rows = await conn.fetch(
                    """
                    SELECT id AS user_id, fcm_token, idioma
                    FROM users
                    WHERE id = $1
                      AND COALESCE(activo, TRUE) = TRUE
                      AND COALESCE(notificaciones_activas, TRUE) = TRUE
                      AND NULLIF(TRIM(fcm_token), '') IS NOT NULL
                    """,
                    user_id,
                )
            elif loteria_id is None:
                rows = await conn.fetch(
                    """
                    SELECT id AS user_id, fcm_token, idioma
                    FROM users
                    WHERE COALESCE(activo, TRUE) = TRUE
                      AND COALESCE(notificaciones_activas, TRUE) = TRUE
                      AND NULLIF(TRIM(fcm_token), '') IS NOT NULL
                    """
                )
            else:
                rows = await conn.fetch(
                    """
                    SELECT DISTINCT u.id AS user_id, u.fcm_token, u.idioma
                    FROM users u
                    JOIN loterias l ON l.id = $1
                    WHERE COALESCE(u.activo, TRUE) = TRUE
                      AND COALESCE(u.notificaciones_activas, TRUE) = TRUE
                      AND NULLIF(TRIM(u.fcm_token), '') IS NOT NULL
                      AND (
                        u.pais_id = l.pais_id
                        OR (
                          $2::date IS NOT NULL
                          AND EXISTS (
                            SELECT 1
                            FROM jugadas j
                            WHERE j.user_id = u.id
                              AND j.loteria_id = $1
                              AND COALESCE(j.fecha_sorteo, j.fecha_guardado::date) = $2::date
                          )
                        )
                      )
                    """,
                    loteria_id,
                    fecha_sorteo,
                )

            unique: Dict[str, Dict[str, Any]] = {}
            for row in rows:
                item = dict(row)
                token = (item.get("fcm_token") or "").strip()
                if token and token not in unique:
                    unique[token] = item
            return list(unique.values())

    async def list_notifications(
        self,
        user_id: Optional[int] = None,
        limit: int = 50,
    ) -> List[Dict[str, Any]]:
        pool = db_connection.get_pool()
        async with pool.acquire() as conn:
            await self._ensure_schema(conn)
            base_query = """
                SELECT n.id, n.usuario_id, n.loteria_id, n.fecha_sorteo, n.mensaje,
                       n.tipo, n.message_key, n.message_params, n.created_at,
                       l.pais_id, l.nombre AS loteria_nombre, l.route AS loteria_route,
                       u.idioma AS usuario_idioma,
                       CASE
                         WHEN n.usuario_id = $1 THEN COALESCE(s.leido, n.leido, FALSE)
                         ELSE COALESCE(s.leido, FALSE)
                       END AS leido
                FROM notificaciones n
                LEFT JOIN loterias l ON l.id = n.loteria_id
                LEFT JOIN users u ON u.id = $1
                LEFT JOIN notification_user_state s
                    ON s.notification_id = n.id AND s.user_id = $1
                WHERE n.created_at >= NOW() - INTERVAL '3 days'
                  AND COALESCE(s.eliminado, FALSE) = FALSE
                  AND (
                    n.usuario_id = $1
                    OR (
                      n.usuario_id IS NULL
                      AND COALESCE(u.notificaciones_activas, TRUE) = TRUE
                      AND (
                        n.loteria_id IS NULL
                        OR l.pais_id = u.pais_id
                        OR EXISTS (
                          SELECT 1 FROM jugadas j
                          WHERE j.user_id = $1
                            AND j.loteria_id = n.loteria_id
                            AND n.fecha_sorteo IS NOT NULL
                            AND COALESCE(j.fecha_sorteo, j.fecha_guardado::date) = n.fecha_sorteo::date
                        )
                      )
                    )
                  )
                ORDER BY n.created_at DESC LIMIT $2
            """

            if user_id is not None:
                rows = await conn.fetch(base_query, user_id, limit)
            else:
                query_no_user = """
                    SELECT n.*, l.pais_id, l.nombre AS loteria_nombre,
                           l.route AS loteria_route, NULL::text AS usuario_idioma
                    FROM notificaciones n
                    LEFT JOIN loterias l ON l.id = n.loteria_id
                    WHERE n.usuario_id IS NULL
                      AND n.created_at >= NOW() - INTERVAL '3 days'
                    ORDER BY n.created_at DESC LIMIT $1
                """
                rows = await conn.fetch(query_no_user, limit)
            notifications: List[Dict[str, Any]] = []
            for row in rows:
                item = dict(row)
                item["message_params"] = self._decode_message_params(
                    item.get("message_params")
                )
                notifications.append(item)
            return notifications

    async def mark_as_read(self, notification_id: int, user_id: int) -> bool:
        pool = db_connection.get_pool()
        async with pool.acquire() as conn:
            await self._ensure_user_state_table(conn)
            result = await conn.execute(
                """
                INSERT INTO notification_user_state
                    (notification_id, user_id, leido, eliminado, updated_at)
                SELECT id, $2, TRUE, FALSE, CURRENT_TIMESTAMP
                FROM notificaciones
                WHERE id = $1 AND (usuario_id = $2 OR usuario_id IS NULL)
                ON CONFLICT (notification_id, user_id)
                DO UPDATE SET leido = TRUE, updated_at = CURRENT_TIMESTAMP
                """,
                notification_id,
                user_id,
            )
            return result in ("INSERT 0 1", "UPDATE 1")

    async def delete_notification(self, notification_id: int, user_id: int) -> bool:
        pool = db_connection.get_pool()
        async with pool.acquire() as conn:
            await self._ensure_user_state_table(conn)
            result = await conn.execute(
                """
                INSERT INTO notification_user_state
                    (notification_id, user_id, leido, eliminado, updated_at)
                SELECT id, $2, TRUE, TRUE, CURRENT_TIMESTAMP
                FROM notificaciones
                WHERE id = $1 AND (usuario_id = $2 OR usuario_id IS NULL)
                ON CONFLICT (notification_id, user_id)
                DO UPDATE SET leido = TRUE, eliminado = TRUE, updated_at = CURRENT_TIMESTAMP
                """,
                notification_id,
                user_id,
            )
            return result in ("INSERT 0 1", "UPDATE 1")
