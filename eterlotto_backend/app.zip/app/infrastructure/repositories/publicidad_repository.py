import logging
import psycopg2
import psycopg2.extras
from typing import List, Optional, Tuple, Dict, Any
from app.domain.ports import PublicidadRepositoryPort
from app.infrastructure import db_connection

logger = logging.getLogger(__name__)

class PostgresPublicidadRepository(PublicidadRepositoryPort):
    async def create_publicidad(self, user_id: int, imagen_url: str, link: str, categoria_id: int, ciudad_id: int, departamento_id: int) -> Dict[str, Any]:
        # En la implementación original se recibe un dict complejo con múltiples campos.
        # Pasaremos esos datos directamente en el caso de uso, pero este método general
        # puede guardar los campos básicos. Para mantener 100% de compatibilidad, 
        # definiremos un método más genérico o que reciba los datos mapeados.
        pass

    async def create_publicidad_full(self, user_id: int, data: Dict[str, Any]) -> Dict[str, Any]:
        pool = db_connection.get_pool()
        async with pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO publicidad (
                    usuario_id, categoria_id, pais_id, departamento_id, ciudad_id,
                    titulo, descripcion, imagen_url, telefono, 
                    facebook_url, instagram_url, whatsapp_url, tiktok_url, pagina_url,
                    direccion, es_24_7, hora_apertura, hora_cierre, dias_atencion, estado_texto,
                    fecha_inicio, fecha_fin, estado, aprobado, pago_confirmado
                )
                VALUES (
                    $1, $2, $3, $4, $5,
                    $6, $7, $8, $9,
                    $10, $11, $12, $13, $14,
                    $15, $16, $17, $18, $19, $20,
                    CURRENT_DATE, CURRENT_DATE + INTERVAL '15 days',
                    TRUE, FALSE, FALSE
                )
            """,
            user_id,
            data.get("categoria_id"),
            data.get("pais_id"),
            data.get("departamento_id"),
            data.get("ciudad_id"),
            data.get("titulo"),
            data.get("descripcion"),
            data.get("imagen_url"),
            data.get("telefono"),
            data.get("facebook_url"),
            data.get("instagram_url"),
            data.get("whatsapp_url"),
            data.get("tiktok_url"),
            data.get("pagina_url"),
            data.get("direccion"),
            bool(data.get("es_24_7", True)),
            data.get("hora_apertura", "00:00"),
            data.get("hora_cierre", "23:59"),
            data.get("dias_atencion", "Todos los días"),
            data.get("estado_texto", "Abierto 24/7")
            )
            return {"success": True, "message": "Anuncio creado exitosamente. Pendiente de aprobación."}

    async def list_publicidad_aprobada(self, categoria_id: Optional[int], departamento_id: Optional[int], ciudad_id: Optional[int]) -> List[Dict[str, Any]]:
        # Este método no se usa directamente tal cual, sino el dinámico de listar_publicidad con filtros
        pass

    async def list_publicidad_dinamica(self, filters: Dict[str, Any], limit: int, offset: int) -> Tuple[List[Dict[str, Any]], int]:
        pool = db_connection.get_pool()
        user_id = filters.get("user_id")
        user_fav_sql = f"COALESCE((SELECT TRUE FROM publicidad_calificaciones pc WHERE pc.publicidad_id = p.id AND pc.user_id = {int(user_id)} LIMIT 1), FALSE)" if user_id else "FALSE"

        base_query = f"""
            SELECT 
                p.*,
                pa.nombre AS pais_nombre,
                d.nombre AS departamento_nombre,
                c.nombre AS categoria_nombre,
                ci.nombre AS ciudad_nombre,
                COALESCE((SELECT COUNT(*) FROM publicidad_calificaciones pc WHERE pc.publicidad_id = p.id), 0) AS total_likes,
                COALESCE((SELECT AVG(pc.estrellas) FROM publicidad_calificaciones pc WHERE pc.publicidad_id = p.id), 0.0) AS promedio_estrellas,
                {user_fav_sql} AS is_favorite
            FROM publicidad p
            LEFT JOIN paises pa ON p.pais_id = pa.id
            LEFT JOIN departamentos d ON p.departamento_id = d.id
            LEFT JOIN categorias c ON p.categoria_id = c.id
            LEFT JOIN ciudades ci ON p.ciudad_id = ci.id
            WHERE p.estado = TRUE
              AND p.aprobado = FALSE
              AND (p.fecha_fin IS NULL OR p.fecha_fin >= CURRENT_DATE)
        """
        params = []
        conditions = []

        if filters.get("pais_id"):
            conditions.append(f"p.pais_id = ${len(params) + 1}")
            params.append(filters["pais_id"])

        if filters.get("departamento_id"):
            conditions.append(f"p.departamento_id = ${len(params) + 1}")
            params.append(filters["departamento_id"])

        if filters.get("ciudad_id"):
            conditions.append(f"p.ciudad_id = ${len(params) + 1}")
            params.append(filters["ciudad_id"])

        if filters.get("categoria_id"):
            conditions.append(f"p.categoria_id = ${len(params) + 1}")
            params.append(filters["categoria_id"])

        if filters.get("titulo") and filters["titulo"].strip():
            conditions.append(f"LOWER(p.titulo) ILIKE LOWER(${len(params) + 1})")
            params.append(f"%{filters['titulo']}%")

        full_query = base_query
        if conditions:
            full_query += " AND " + " AND ".join(conditions)

        full_query += f" ORDER BY p.fecha_creacion DESC NULLS LAST LIMIT ${len(params) + 1} OFFSET ${len(params) + 2}"
        
        count_params = list(params)
        params.extend([limit, offset])

        async with pool.acquire() as conn:
            rows = await conn.fetch(full_query, *params)
            data = [dict(row) for row in rows]

            # Reemplazar de forma limpia y simplificada para evitar errores de matching de strings multilinea largos
            simplified_count_query = f"""
                SELECT COUNT(*)
                FROM publicidad p
                WHERE p.estado = TRUE
                  AND p.aprobado = FALSE
                  AND (p.fecha_fin IS NULL OR p.fecha_fin >= CURRENT_DATE)
            """
            if conditions:
                simplified_count_query += " AND " + " AND ".join(conditions)

            total = await conn.fetchval(simplified_count_query, *count_params) or 0
            return data, total

    async def list_all_publicidades(self) -> List[Dict[str, Any]]:
        pass

    async def list_my_publicidades(self, user_id: int) -> List[Dict[str, Any]]:
        pool = db_connection.get_pool()
        async with pool.acquire() as conn:
            query = """
                SELECT 
                    p.*, 
                    c.nombre AS categoria_nombre,
                    ci.nombre AS ciudad_nombre,
                    d.nombre AS departamento_nombre,
                    COALESCE((SELECT COUNT(*) FROM publicidad_calificaciones pc WHERE pc.publicidad_id = p.id), 0) AS total_likes,
                    COALESCE((SELECT AVG(pc.estrellas) FROM publicidad_calificaciones pc WHERE pc.publicidad_id = p.id), 0.0) AS promedio_estrellas,
                    COALESCE((SELECT TRUE FROM publicidad_calificaciones pc WHERE pc.publicidad_id = p.id AND pc.user_id = $1 LIMIT 1), FALSE) AS is_favorite
                FROM publicidad p
                LEFT JOIN categorias c ON p.categoria_id = c.id
                LEFT JOIN ciudades ci ON p.ciudad_id = ci.id
                LEFT JOIN departamentos d ON p.departamento_id = d.id
                WHERE p.usuario_id = $1
                ORDER BY p.id DESC
            """
            rows = await conn.fetch(query, user_id)
            return [dict(r) for r in rows]

    async def update_publicidad(self, publicidad_id: int, user_id: int, imagen_url: Optional[str], link: Optional[str], categoria_id: Optional[int], ciudad_id: Optional[int], departamento_id: Optional[int]) -> Optional[Dict[str, Any]]:
        pass

    async def update_publicidad_full(self, publicidad_id: int, user_id: int, data: Dict[str, Any]) -> bool:
        pool = db_connection.get_pool()
        async with pool.acquire() as conn:
            existe = await conn.fetchrow("SELECT 1 FROM publicidad WHERE id = $1 AND usuario_id = $2", publicidad_id, user_id)
            if not existe:
                return False

            query = """
                UPDATE publicidad SET
                    titulo = $1,
                    descripcion = $2,
                    direccion = $3,
                    pais_id = $4,
                    departamento_id = $5,
                    ciudad_id = COALESCE($6, ciudad_id),
                    categoria_id = $7,
                    imagen_url = $8,
                    telefono = $9,
                    facebook_url = COALESCE($10, facebook_url),
                    instagram_url = COALESCE($11, instagram_url),
                    whatsapp_url = COALESCE($12, whatsapp_url),
                    tiktok_url = COALESCE($13, tiktok_url),
                    pagina_url = COALESCE($14, pagina_url),
                    es_24_7 = COALESCE($15, es_24_7),
                    hora_apertura = COALESCE($16, hora_apertura),
                    hora_cierre = COALESCE($17, hora_cierre),
                    dias_atencion = COALESCE($18, dias_atencion),
                    estado_texto = COALESCE($19, estado_texto),
                    fecha_fin = CASE 
                        WHEN pago_confirmado = FALSE THEN CURRENT_DATE + INTERVAL '15 days'
                        ELSE fecha_fin
                     END
                WHERE id = $20
            """
            await conn.execute(query,
                data.get("titulo"),
                data.get("descripcion"),
                data.get("direccion"),
                data.get("pais_id"),
                data.get("departamento_id"),
                data.get("ciudad_id"),
                data.get("categoria_id"),
                data.get("imagen_url"),
                data.get("telefono"),
                data.get("facebook_url"),
                data.get("instagram_url"),
                data.get("whatsapp_url"),
                data.get("tiktok_url"),
                data.get("pagina_url"),
                data.get("es_24_7"),
                data.get("hora_apertura"),
                data.get("hora_cierre"),
                data.get("dias_atencion"),
                data.get("estado_texto"),
                publicidad_id
            )
            return True

    async def delete_publicidad(self, publicidad_id: int) -> bool:
        pass

    async def delete_publicidad_by_user(self, publicidad_id: int, user_id: int) -> bool:
        pool = db_connection.get_pool()
        async with pool.acquire() as conn:
            result = await conn.execute("""
                DELETE FROM publicidad
                WHERE id = $1 AND usuario_id = $2
            """, publicidad_id, user_id)
            return result == "DELETE 1"

    async def calificar_publicidad(self, user_id: int, publicidad_id: int, estrellas: int) -> Dict[str, Any]:
        pool = db_connection.get_pool()
        async with pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO publicidad_calificaciones (publicidad_id, user_id, estrellas, created_at)
                VALUES ($1, $2, $3, CURRENT_TIMESTAMP)
                ON CONFLICT (publicidad_id, user_id)
                DO UPDATE SET estrellas = EXCLUDED.estrellas, created_at = CURRENT_TIMESTAMP
            """, publicidad_id, user_id, estrellas)

            stats = await conn.fetchrow("""
                SELECT 
                    COALESCE(AVG(estrellas), 0.0) AS promedio,
                    COUNT(*) AS total_votos
                FROM publicidad_calificaciones
                WHERE publicidad_id = $1
            """, publicidad_id)

            promedio = float(stats["promedio"]) if stats else 0.0
            total_votos = int(stats["total_votos"]) if stats else 0

            return {
                "success": True,
                "promedio": round(promedio, 1),
                "total_votos": total_votos,
                "is_destacado": promedio >= 4.5 and total_votos >= 3
            }

    async def toggle_favorito(self, user_id: int, publicidad_id: int) -> Dict[str, Any]:
        pool = db_connection.get_pool()
        async with pool.acquire() as conn:
            existe = await conn.fetchrow("""
                SELECT estrellas FROM publicidad_calificaciones 
                WHERE publicidad_id = $1 AND user_id = $2
            """, publicidad_id, user_id)

            if existe:
                await conn.execute("""
                    DELETE FROM publicidad_calificaciones 
                    WHERE publicidad_id = $1 AND user_id = $2
                """, publicidad_id, user_id)
                is_fav = False
            else:
                await conn.execute("""
                    INSERT INTO publicidad_calificaciones (publicidad_id, user_id, estrellas, created_at)
                    VALUES ($1, $2, 5, CURRENT_TIMESTAMP)
                    ON CONFLICT (publicidad_id, user_id)
                    DO UPDATE SET estrellas = 5, created_at = CURRENT_TIMESTAMP
                """, publicidad_id, user_id)
                is_fav = True

            stats = await conn.fetchrow("""
                SELECT 
                    COALESCE(AVG(estrellas), 0.0) AS promedio,
                    COUNT(*) AS total_votos
                FROM publicidad_calificaciones
                WHERE publicidad_id = $1
            """, publicidad_id)

            promedio = float(stats["promedio"]) if stats else 0.0
            total_votos = int(stats["total_votos"]) if stats else 0

            return {
                "success": True,
                "is_favorite": is_fav,
                "promedio": round(promedio, 1),
                "total_votos": total_votos,
                "is_destacado": promedio >= 4.5 and total_votos >= 3
            }

    async def aprobar_publicidad(self, publicidad_id: int, admin_user_id: int) -> bool:
        pool = db_connection.get_pool()
        async with pool.acquire() as conn:
            is_admin = await conn.fetchval("SELECT is_super_admin FROM users WHERE id = $1", admin_user_id)
            if not is_admin:
                raise PermissionError("Permisos insuficientes para aprobar publicidad")
                
            result = await conn.execute("""
                UPDATE publicidad
                SET aprobado = TRUE, pago_confirmado = TRUE
                WHERE id = $1
            """, publicidad_id)
            return result == "UPDATE 1"

    def list_categorias(self) -> List[Dict[str, Any]]:
        with db_connection.get_connection() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute("SELECT * FROM categorias ORDER BY nombre")
                return cur.fetchall()

    def list_paises(self) -> List[Dict[str, Any]]:
        with db_connection.get_connection() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute("SELECT id, nombre FROM paises ORDER BY nombre;")
                return cur.fetchall()

    def list_departamentos(self, pais_id: int) -> List[Dict[str, Any]]:
        with db_connection.get_connection() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute("SELECT id, nombre FROM departamentos WHERE pais_id = %s ORDER BY nombre", (pais_id,))
                return cur.fetchall()

    def list_departamentos_all(self) -> List[Dict[str, Any]]:
        with db_connection.get_connection() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute("SELECT * FROM departamentos ORDER BY nombre")
                return cur.fetchall()

    def list_ciudades(self) -> List[Dict[str, Any]]:
        with db_connection.get_connection() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute("SELECT * FROM ciudades ORDER BY nombre")
                return cur.fetchall()

    def list_ciudades_by_departamento(self, departamento_id: int) -> List[Dict[str, Any]]:
        with db_connection.get_connection() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute("SELECT * FROM ciudades WHERE departamento_id = %s ORDER BY nombre", (departamento_id,))
                return cur.fetchall()

    def list_loterias(self) -> List[Dict[str, Any]]:
        return self.list_loterias_by_pais(None)

    def list_loterias_by_pais(self, pais_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with db_connection.get_connection() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                try:
                    if pais_id:
                        cur.execute("""
                            SELECT id, nombre, tipo, pais_id,
                                   COALESCE(route, '') AS route,
                                   COALESCE(max_seleccion, 5) AS max_seleccion,
                                   COALESCE(max_balotas_blancas, 45) AS max_balotas_blancas,
                                   COALESCE(max_balotas_rojas, 0) AS max_balotas_rojas,
                                   superbalota_nombre,
                                   COALESCE(has_revancha, false) AS has_revancha,
                                   COALESCE(total_balotas_sorteo, 5) AS total_balotas_sorteo,
                                   COALESCE(tiene_complementario, false) AS tiene_complementario,
                                   COALESCE(tiene_reintegro, false) AS tiene_reintegro
                            FROM loterias
                            WHERE pais_id = %s
                              AND activa = true
                            ORDER BY nombre
                        """, (pais_id,))
                    else:
                        cur.execute("""
                            SELECT id, nombre, tipo, pais_id,
                                   COALESCE(route, '') AS route,
                                   COALESCE(max_seleccion, 5) AS max_seleccion,
                                   COALESCE(max_balotas_blancas, 45) AS max_balotas_blancas,
                                   COALESCE(max_balotas_rojas, 0) AS max_balotas_rojas,
                                   superbalota_nombre,
                                   COALESCE(has_revancha, false) AS has_revancha,
                                   COALESCE(total_balotas_sorteo, 5) AS total_balotas_sorteo,
                                   COALESCE(tiene_complementario, false) AS tiene_complementario,
                                   COALESCE(tiene_reintegro, false) AS tiene_reintegro
                            FROM loterias
                            WHERE activa = true
                            ORDER BY nombre
                        """)
                    loterias = cur.fetchall()
                except Exception as e:
                    # Fallback si las nuevas columnas aún no se han creado en la BD
                    logger.warning(f"Columnas nuevas de loterias no encontradas (ejecute la migración SQL): {e}")
                    conn.rollback()
                    if pais_id:
                        cur.execute("""
                            SELECT id, nombre, tipo, pais_id
                            FROM loterias
                            WHERE pais_id = %s
                              AND activa = true
                            ORDER BY nombre
                        """, (pais_id,))
                    else:
                        cur.execute("""
                            SELECT id, nombre, tipo, pais_id
                            FROM loterias
                            WHERE activa = true
                            ORDER BY nombre
                        """)
                    loterias = cur.fetchall()

                # ⚡ 1. Precargar todas las tablas de resultados existentes en 1 sola consulta
                existing_tables = set()
                try:
                    cur.execute("""
                        SELECT table_name 
                        FROM information_schema.tables 
                        WHERE table_schema = 'public' AND table_name LIKE 'resultados_%';
                    """)
                    for t_row in cur.fetchall():
                        t_name = t_row['table_name'] if isinstance(t_row, dict) else t_row[0]
                        if t_name:
                            existing_tables.add(t_name.lower())
                except Exception as et:
                    try:
                        conn.rollback()
                    except Exception as e:
                        logging.getLogger(__name__).error(f'Error capturado: {e}')
                        pass
                    logger.debug(f"Error precargando tablas de resultados: {et}")

                # ⚡ 2. Precargar los jackpots más recientes en 1 sola consulta
                jackpot_map = {}
                try:
                    cur.execute("""
                        SELECT DISTINCT ON (LOWER(TRIM(loteria))) LOWER(TRIM(loteria)) AS lot, jackpot
                        FROM loterias_jackpots
                        ORDER BY LOWER(TRIM(loteria)), fecha DESC;
                    """)
                    for j_row in cur.fetchall():
                        lot_k = j_row['lot'] if isinstance(j_row, dict) else j_row[0]
                        j_val = j_row['jackpot'] if isinstance(j_row, dict) else j_row[1]
                        if lot_k and j_val:
                            s_val = str(j_val)
                            jackpot_map[lot_k] = s_val
                            jackpot_map[lot_k.replace('_', ' ')] = s_val
                            jackpot_map[lot_k.replace(' ', '_')] = s_val
                except Exception as ej:
                    try:
                        conn.rollback()
                    except Exception as e:
                        logging.getLogger(__name__).error(f'Error capturado: {e}')
                        pass
                    logger.debug(f"Error precargando jackpots: {ej}")

                # ⚡ 3. Asignar próximo sorteo y jackpot sin consultas redundantes
                for lot in loterias:
                    r = (lot.get('route') or '').strip().lower()
                    if not r:
                        r = lot['nombre'].lower().strip().replace(' ', '_')
                        lot['route'] = r

                    tabla = f"resultados_{r}"
                    if r in ['colorloto', 'cloto']:
                        tabla = 'resultados_colorloto2' if 'resultados_colorloto2' in existing_tables else 'resultados_colorloto'

                    if tabla in existing_tables:
                        try:
                            if 'colorloto' in tabla:
                                cur.execute(f"SELECT MAX(fecha) AS max_fecha FROM {tabla} WHERE numero = 0")
                                res = cur.fetchone()
                                if res:
                                    max_fecha = res['max_fecha'] if isinstance(res, dict) and 'max_fecha' in res else res[0]
                                    if max_fecha:
                                        lot['proximo_sorteo'] = str(max_fecha)

                                cur.execute(f"SELECT MAX(fecha) AS ult_fecha FROM {tabla} WHERE numero > 0")
                                res_u = cur.fetchone()
                                if res_u:
                                    ult_fecha = res_u['ult_fecha'] if isinstance(res_u, dict) and 'ult_fecha' in res_u else res_u[0]
                                    if ult_fecha:
                                        lot['ultimo_sorteo'] = str(ult_fecha)

                            else:
                                cur.execute(f"SELECT MAX(fecha) AS max_fecha FROM {tabla} WHERE balota1 = 0")
                                res = cur.fetchone()
                                if res:
                                    max_fecha = res['max_fecha'] if isinstance(res, dict) and 'max_fecha' in res else res[0]
                                    if max_fecha:
                                        lot['proximo_sorteo'] = str(max_fecha)

                                cur.execute(f"SELECT MAX(fecha) AS ult_fecha FROM {tabla} WHERE balota1 > 0")
                                res_u = cur.fetchone()
                                if res_u:
                                    ult_fecha = res_u['ult_fecha'] if isinstance(res_u, dict) and 'ult_fecha' in res_u else res_u[0]
                                    if ult_fecha:
                                        lot['ultimo_sorteo'] = str(ult_fecha)

                        except Exception as e:
                            logging.getLogger(__name__).error(f'Error capturado: {e}')
                            try:
                                conn.rollback()
                            except Exception as e:
                                logging.getLogger(__name__).error(f'Error capturado: {e}')
                                pass

                    # Fallback a tabla predicciones si proximo_sorteo no se encontró en la tabla de resultados
                    if not lot.get('proximo_sorteo'):
                        try:
                            cur.execute("SELECT MAX(fecha) AS p_fecha FROM predicciones WHERE LOWER(loteria_route) = %s", (r,))
                            p_res = cur.fetchone()
                            if p_res:
                                p_fecha = p_res['p_fecha'] if isinstance(p_res, dict) and 'p_fecha' in p_res else p_res[0]
                                if p_fecha:
                                    lot['proximo_sorteo'] = str(p_fecha)
                        except Exception as e:
                            logging.getLogger(__name__).error(f'Error capturado: {e}')
                            try:
                                conn.rollback()
                            except Exception as e:
                                logging.getLogger(__name__).error(f'Error capturado: {e}')
                                pass

                    # Búsqueda instantánea en mapa de jackpots en memoria (0 ms)
                    nombre_lower = lot['nombre'].lower().strip()
                    j_val = (
                        jackpot_map.get(r) or 
                        jackpot_map.get(nombre_lower) or 
                        jackpot_map.get(r.replace('_', ' ')) or
                        jackpot_map.get(nombre_lower.replace(' ', '_'))
                    )
                    if j_val:
                        lot['jackpot'] = j_val

                return loterias
