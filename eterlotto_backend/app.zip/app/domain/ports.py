from abc import ABC, abstractmethod
from typing import List, Optional, Tuple, Dict, Any
from datetime import datetime, date

class UserRepositoryPort(ABC):
    @abstractmethod
    async def find_by_id(self, user_id: int) -> Optional[Dict[str, Any]]:
        pass

    @abstractmethod
    async def find_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        pass

    @abstractmethod
    async def create(
        self,
        name: str,
        email: str,
        password_hashed: Optional[str],
        pais_id: Optional[int],
        departamento_id: Optional[int],
        auth_provider: str = 'email',
        email_verified: bool = False,
        avatar_url: Optional[str] = None,
        terms_accepted_at: Optional[datetime] = None,
        is_adult: bool = True
    ) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def update_last_login(self, user_id: int) -> None:
        pass

    @abstractmethod
    async def update(self, user_id: int, updates: Dict[str, Any]) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def delete(self, user_id: int) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def save_password_reset_token(self, user_id: int, token: str, expires: datetime) -> None:
        pass

    @abstractmethod
    async def find_password_reset_token(self, token: str) -> Optional[Tuple[int, datetime]]:
        pass

    @abstractmethod
    async def update_password(self, user_id: int, new_password_hashed: str) -> None:
        pass

    @abstractmethod
    async def save_email_verification_code(self, user_id: int, code: str, expires: datetime) -> None:
        pass

    @abstractmethod
    async def find_email_verification_code(self, user_id: int, code: str) -> Optional[datetime]:
        pass

    @abstractmethod
    async def verify_user_email(self, user_id: int) -> None:
        pass

    @abstractmethod
    async def set_premium(
        self,
        user_id: int,
        is_premium: bool,
        expires_at: Optional[datetime] = None,
        order_id: Optional[str] = None,
        purchase_token: Optional[str] = None,
        product_id: Optional[str] = None
    ) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def find_user_id_by_purchase_token(self, purchase_token: str) -> Optional[int]:
        pass

    @abstractmethod
    async def update_subscription_state(
        self,
        user_id: int,
        is_premium: bool,
        expires_at: Optional[datetime] = None,
        purchase_token: Optional[str] = None,
        product_id: Optional[str] = None,
        order_id: Optional[str] = None,
        status: Optional[str] = None
    ) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def mark_expired_subscriptions(self, user_id: int) -> bool:
        pass

    @abstractmethod
    async def find_current_subscription(self, user_id: int) -> Optional[Dict[str, Any]]:
        pass


class JugadaRepositoryPort(ABC):
    @abstractmethod
    async def create_jugada(self, tipo: str, user_id: int, numeros: List[int], fecha_sorteo: Optional[date], fecha_guardado: datetime, expira: datetime, loteria_id: Optional[int] = None) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def list_jugadas(self, tipo: str, user_id: int, fecha: Optional[str] = None, loteria_id: Optional[int] = None) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    async def delete_jugada(self, tipo: str, jugada_id: int, user_id: int, loteria_id: Optional[int] = None) -> bool:
        pass

    @abstractmethod
    async def update_jugada(self, tipo: str, jugada_id: int, user_id: int, numeros: List[int], loteria_id: Optional[int] = None) -> Optional[Dict[str, Any]]:
        pass

    @abstractmethod
    async def list_active_lotteries(self, user_id: int) -> List[str]:
        pass

    @abstractmethod
    async def list_active_lotteries_counts(self, user_id: int) -> Dict[str, int]:
        pass

    @abstractmethod
    async def list_active_lotteries_info(self, user_id: int) -> Dict[str, Dict[str, Any]]:
        pass

    @abstractmethod
    def get_prediccion_reciente_mloto(self, fecha: Optional[str] = None) -> Optional[Tuple[datetime, List[int]]]:
        pass

    @abstractmethod
    def get_prediccion_reciente_bloto(self, fecha: Optional[str] = None) -> Optional[Tuple[datetime, List[int], List[int]]]:
        pass

    @abstractmethod
    def get_jackpot_reciente(self, loteria: str) -> Optional[str]:
        pass

    @abstractmethod
    def get_ultimos_resultados_mloto(self) -> List[Tuple[datetime, List[int], Optional[str]]]:
        pass

    @abstractmethod
    def get_ultimos_resultados_bloto(self, sorteo: Optional[str] = None) -> List[Tuple[datetime, List[int], List[int], str, Optional[str]]]:
        pass

    @abstractmethod
    def get_historico_completo_bloto(self, sorteo: Optional[str] = None) -> List[Tuple[datetime, List[int], List[int], str, Optional[str]]]:
        pass

    @abstractmethod
    def get_historico_completo_mloto(self) -> List[Tuple[datetime, List[int], Optional[str]]]:
        pass

    @abstractmethod
    def get_predicciones_historico(self, tipo: str, limit: int) -> List[Tuple[datetime, List[int]]]:
        pass

    @abstractmethod
    def get_predicciones_historico_completas(self, tipo: str, limit: int = 50) -> List[Tuple[datetime, List[int], List[int]]]:
        pass

    @abstractmethod
    def get_prediccion_generico(self, tabla: str) -> Optional[Tuple[datetime, List[int], List[int]]]:
        pass

    @abstractmethod
    def get_ultimos_resultados_generico(self, tabla: str, sorteo_nombre: str) -> List[Tuple[datetime, List[int], List[int], str, Optional[str]]]:
        pass

    @abstractmethod
    def get_ultimos50_resultados_generico(self, tabla: str, sorteo_nombre: str) -> List[Tuple[datetime, List[int], List[int], str, Optional[str]]]:
        pass

    @abstractmethod
    def get_historico_completo_generico(self, tabla: str, sorteo_nombre: str) -> List[Tuple[datetime, List[int], List[int], str, Optional[str]]]:
        pass



class PostRepositoryPort(ABC):
    @abstractmethod
    async def create_post(self, title: str, content: str, user_id: int) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def list_posts(self, skip: int, limit: int) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    async def update_post(self, post_id: int, title: str, content: str, user_id: int) -> Optional[Dict[str, Any]]:
        pass

    @abstractmethod
    async def delete_post(self, post_id: int, user_id: int) -> bool:
        pass

    @abstractmethod
    async def create_comment(self, post_id: int, user_id: int, content: str, parent_id: Optional[int] = None, status: str = "active", moderation_reason: Optional[str] = None) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def update_comment(self, comment_id: int, user_id: int, content: str) -> Optional[Dict[str, Any]]:
        pass

    @abstractmethod
    async def delete_comment(self, comment_id: int, user_id: int) -> bool:
        pass

    @abstractmethod
    async def report_comment(self, comment_id: int, reporter_user_id: int) -> bool:
        pass

    @abstractmethod
    async def list_comments_by_post(
        self,
        post_id: int,
        requesting_user_id: int,
    ) -> List[Dict[str, Any]]:
        pass


class PublicidadRepositoryPort(ABC):
    @abstractmethod
    async def create_publicidad(self, user_id: int, imagen_url: str, link: str, categoria_id: int, ciudad_id: int, departamento_id: int) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def list_publicidad_aprobada(self, categoria_id: Optional[int], departamento_id: Optional[int], ciudad_id: Optional[int]) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    async def list_all_publicidades(self) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    async def list_my_publicidades(self, user_id: int) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    async def update_publicidad(self, publicidad_id: int, user_id: int, imagen_url: Optional[str], link: Optional[str], categoria_id: Optional[int], ciudad_id: Optional[int], departamento_id: Optional[int]) -> Optional[Dict[str, Any]]:
        pass

    @abstractmethod
    async def delete_publicidad(self, publicidad_id: int) -> bool:
        pass

    @abstractmethod
    async def calificar_publicidad(self, user_id: int, publicidad_id: int, estrellas: int) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def toggle_favorito(self, user_id: int, publicidad_id: int) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def aprobar_publicidad(self, publicidad_id: int, admin_user_id: int) -> bool:
        pass

    @abstractmethod
    def list_categorias(self) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    def list_paises(self) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    def list_departamentos(self, pais_id: int) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    def list_departamentos_all(self) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    def list_ciudades(self) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    def list_loterias(self) -> List[Dict[str, Any]]:
        pass


class TransactionRepositoryPort(ABC):
    @abstractmethod
    def create_transaction(self, referencia: str, nombre_cliente: str, email_cliente: str, monto: float, moneda: str, descripcion: str) -> int:
        pass

    @abstractmethod
    async def update_transaction_confirmation(self, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        pass


class EmailSenderPort(ABC):
    @abstractmethod
    async def send_reset_password_email(self, email: str, reset_link: str) -> bool:
        pass

    @abstractmethod
    async def send_reset_password_code(self, email: str, code: str) -> bool:
        pass

    @abstractmethod
    async def send_verification_code(self, email: str, code: str) -> bool:
        pass


class NotificationRepositoryPort(ABC):
    @abstractmethod
    async def create_notification(self, loteria_id: Optional[int], fecha_sorteo: Optional[datetime], mensaje: str, tipo: str, user_id: Optional[int] = None) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def list_notifications(self, user_id: Optional[int] = None, limit: int = 20) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    async def mark_as_read(self, notification_id: int, user_id: int) -> bool:
        pass

    @abstractmethod
    async def delete_notification(self, notification_id: int, user_id: Optional[int] = None) -> bool:
        pass


class GooglePlayPort(ABC):
    @abstractmethod
    async def verify_subscription_token(self, package_name: str, product_id: str, purchase_token: str) -> Dict[str, Any]:
        pass
