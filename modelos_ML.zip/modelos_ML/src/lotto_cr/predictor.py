import sys
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', line_buffering=True)
import pandas as pd
import numpy as np
from datetime import datetime
from pathlib import Path
from xgboost import XGBClassifier
from sqlalchemy import text

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
from config.database import get_engine

class LottoCostaRicaPredictor:
    def __init__(self):
        self.engine = get_engine()
        self.max_balota = 40
        self.loteria_id = 35
        self.loteria_route = 'lotto_cr'

    def cargar_datos(self) -> pd.DataFrame:
        query = "SELECT * FROM resultados_lotto_cr WHERE sorteo = 'Lotto' ORDER BY fecha ASC;"
        with self.engine.connect() as conn:
            df = pd.read_sql(text(query), conn)
        return df

    def run(self):
        print("🔮 Iniciando Predictor de Lotto Costa Rica (XGBoost)...")
        df = self.cargar_datos()

        if df.empty or len(df) < 15:
            print("⚠️ Insuficientes datos históricos para entrenar el modelo de Lotto CR.")
            return

        df['fecha'] = pd.to_datetime(df['fecha'])
        df = df.sort_values('fecha').reset_index(drop=True)

        proxima_fecha = df.iloc[-1]['fecha'].strftime('%Y-%m-%d')
        print(f"Próximo sorteo a predecir para Lotto CR: {proxima_fecha}")

        is_ph = (df['balota1'] == 0) & (df['balota2'] == 0) & (df['balota3'] == 0) & (df['balota4'] == 0) & (df['balota5'] == 0)
        df_real = df[~is_ph].copy().reset_index(drop=True)
        if len(df_real) < 10:
            print("⚠️ Insuficientes sorteos reales para entrenar.")
            return

        # -------------------------------------------------------------
        # 1. Matriz de Balotas Principales (0 a 40)
        # -------------------------------------------------------------
        binary_dict = {}
        for i in range(0, self.max_balota + 1):
            b_match = (
                (df['balota1'] == i) |
                (df['balota2'] == i) |
                (df['balota3'] == i) |
                (df['balota4'] == i) |
                (df['balota5'] == i)
            )
            if i == 0:
                b_match = b_match & ~is_ph
            binary_dict[f'b_{i}'] = b_match.astype(int)

        df_b = pd.concat([df, pd.DataFrame(binary_dict, index=df.index)], axis=1)
        cols_balotas = [f'b_{i}' for i in range(0, self.max_balota + 1)]

        feat_dict = {
            'dia_semana': df_b['fecha'].dt.dayofweek,
            'mes': df_b['fecha'].dt.month,
            'dia': df_b['fecha'].dt.day
        }

        for lag in [1, 2, 3]:
            for col in cols_balotas:
                feat_dict[f'{col}_lag_{lag}'] = df_b[col].shift(lag)

        for w in [5, 10, 20]:
            for col in cols_balotas:
                feat_dict[f'{col}_roll_sum_{w}'] = df_b[col].shift(1).rolling(w, min_periods=1).sum()

        df_features = pd.DataFrame(feat_dict, index=df_b.index).fillna(0)
        X_pred = df_features.iloc[[-1]]

        train_idx = df_real.index[-500:] if len(df_real) > 500 else df_real.index[3:]
        X_train = df_features.iloc[train_idx]

        # Entrenar clasificadores para cada balota
        probabilidades = {}
        for i in range(0, self.max_balota + 1):
            target_col = f'b_{i}'
            y_train = df_b.iloc[train_idx][target_col]

            if y_train.nunique() < 2:
                probabilidades[i] = 0.05
                continue

            model = XGBClassifier(
                n_estimators=60,
                max_depth=4,
                learning_rate=0.05,
                eval_metric='logloss',
                random_state=42,
                n_jobs=1
            )
            model.fit(X_train, y_train)

            proba = model.predict_proba(X_pred)[0][1]
            probabilidades[i] = float(proba)

        # Ordenar balotas por probabilidad descendente
        ranking_balotas = sorted(probabilidades.items(), key=lambda x: x[1], reverse=True)
        top_balotas = [num for num, _ in ranking_balotas]

        # -------------------------------------------------------------
        # 2. Guardar Predicción en BD (Tabla 'predicciones')
        # -------------------------------------------------------------
        try:
            with self.engine.connect() as conn:
                lot_row = conn.execute(text("SELECT id FROM loterias WHERE LOWER(route) = 'lotto_cr' LIMIT 1")).fetchone()
                if lot_row:
                    self.loteria_id = lot_row[0]

                insert_query = text("""
                    INSERT INTO predicciones (loteria_id, loteria_route, fecha, numeros, balotaroja, created_at)
                    VALUES (:loteria_id, :loteria_route, :fecha, :numeros, :balotaroja, CURRENT_TIMESTAMP)
                    ON CONFLICT (loteria_route, fecha)
                    DO UPDATE SET 
                        loteria_id = EXCLUDED.loteria_id,
                        numeros = EXCLUDED.numeros,
                        balotaroja = EXCLUDED.balotaroja,
                        created_at = CURRENT_TIMESTAMP;
                """)

                conn.execute(insert_query, {
                    "loteria_id": self.loteria_id,
                    "loteria_route": self.loteria_route,
                    "fecha": proxima_fecha,
                    "numeros": top_balotas,
                    "balotaroja": None
                })
                conn.commit()

            print(f"✅ Predicción de Lotto Costa Rica guardada exitosamente en BD para la fecha: {proxima_fecha}")
            print(f"Top 20 números más probables: {top_balotas[:20]}")
        except Exception as e:
            print(f"⚠️ Error guardando predicción de Lotto CR: {e}")

if __name__ == "__main__":
    predictor = LottoCostaRicaPredictor()
    predictor.run()
