import 'package:flutter/material.dart';
import 'package:eterlotto/widgets/data_state_widgets.dart';
import 'package:eterlotto/services/api_service.dart';
import 'package:eterlotto/services/cache_service.dart';
import 'package:eterlotto/styles/colores.dart';
import 'package:eterlotto/styles/app_text_styles.dart';
import 'package:eterlotto/widgets/lottery_avatar_3d.dart';
import 'package:eterlotto/utils/pais_helper.dart';
import 'package:eterlotto/screens/resultados_dashboard_screen.dart';
import 'package:eterlotto/l10n/generated/app_localizations.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shimmer/shimmer.dart';



import 'package:eterlotto/services/data_refresh_manager.dart';
import 'package:provider/provider.dart';
import 'package:eterlotto/providers/subscription_provider.dart';
import 'package:eterlotto/widgets/premium_crown_badge.dart';
import '../utils/secure_storage_helper.dart';

class ResultadosSelectorScreen extends StatefulWidget {
  const ResultadosSelectorScreen({super.key});

  @override
  State<ResultadosSelectorScreen> createState() => ResultadosSelectorScreenState();
}

class ResultadosSelectorScreenState extends State<ResultadosSelectorScreen> {
  // Un sorteo permanece en 'Recientes' durante todo el día siguiente.
  // Ej.: sorteo 13 Sep -> sigue reciente el 14 Sep -> pasa a historial el 15 Sep.
  static const int _recentGraceDaysAfterDraw = 1;
  List<Map<String, dynamic>> _loterias = [];
  List<Map<String, dynamic>> _filteredLoterias = [];
  List<Map<String, dynamic>> _paises = [];
  final _storage = AppSecureStorage.instance;
  String? _userCountry;
  String? _userCountryId;
  Set<String> _activePlayedRoutes = <String>{};
  Set<String> _pastPlayedRoutes = <String>{};
  Set<String> _activePlayedLotteryIds = <String>{};
  Set<String> _pastPlayedLotteryIds = <String>{};
  bool _isLoading = true;
  bool _loadFailed = false;
  bool _showingStaleData = false;
  bool _catalogFetchFailed = false;
  String _selectedFilter = 'recientes';

  @override
  void initState() {
    super.initState();
    CacheService.jugadasChangeNotifier.addListener(_onJugadasChanged);
    DataRefreshManager.instance.refreshNotifier.addListener(_onDataRefreshNotification);
    cargarLoterias();
  }

  @override
  void dispose() {
    CacheService.jugadasChangeNotifier.removeListener(_onJugadasChanged);
    DataRefreshManager.instance.refreshNotifier.removeListener(_onDataRefreshNotification);
    super.dispose();
  }

  void _onJugadasChanged() {
    if (mounted) {
      cargarLoterias(forceRefresh: true);
    }
  }

  void _onDataRefreshNotification() {
    final module = DataRefreshManager.instance.refreshNotifier.value;
    if (module == RefreshModules.resultados ||
        module == RefreshModules.loterias ||
        module == 'all') {
      if (mounted) {
        cargarLoterias(forceRefresh: false);
      }
    }
  }

  Future<void> cargarLoterias({bool forceRefresh = false}) async {
    if (!mounted) return;

    final uCountry = await _storage.read(key: 'pais_nombre') ?? "Internacional";
    final uCountryId = await _storage.read(key: 'pais_id');
    final userId = await _storage.read(key: 'user_id');

    if (forceRefresh) {
      await CacheService.invalidateLotteryCatalogCaches();
    }

    // Los resultados son públicos; la información de jugadas usada para
    // decidir Recientes/Historial sí es privada y se aísla por usuario.
    const cacheKey = 'resultados_selector_v6';
    final playsCacheKey = CacheService.infoMisJugadasKey(userId);

    final cached = await CacheService.getStaleJson(cacheKey);
    final cachedPaises = await CacheService.getStaleJson('paises_list_cache');
    final cachedPlaysRaw = await CacheService.getStaleJson(playsCacheKey);

    Map<String, Map<String, dynamic>> cachedPlays =
        <String, Map<String, dynamic>>{};
    if (cachedPlaysRaw is Map) {
      cachedPlays = cachedPlaysRaw.map(
        (key, value) => MapEntry(
          key.toString(),
          value is Map
              ? Map<String, dynamic>.from(value)
              : <String, dynamic>{},
        ),
      );
    }

    if (cached is List && cached.isNotEmpty && mounted) {
      final cachedWithResults = List<Map<String, dynamic>>.from(cached)
          .where(_hasRecordedDraw)
          .toList();
      setState(() {
        _userCountry = uCountry;
        _userCountryId = uCountryId;
        _loterias = cachedWithResults;
        if (cachedPaises is List && cachedPaises.isNotEmpty) {
          _paises = List<Map<String, dynamic>>.from(cachedPaises);
        }
        _setPlayedRoutes(cachedPlays);
        _filteredLoterias = _filterBySelectedView(_loterias);
        _isLoading = false;
        _loadFailed = false;
      });
    }

    if (_loterias.isEmpty && mounted) {
      setState(() {
        _isLoading = true;
        _loadFailed = false;
      });
    }

    var userPlaysFailed = false;
    final userPlaysFuture = ApiService.getLoteriasInfoJugadas(
      forceRefresh: forceRefresh,
    ).catchError((_) {
      userPlaysFailed = true;
      return <String, Map<String, dynamic>>{};
    });

    try {
      final results = await Future.wait([
        _obtenerTodasLasLoterias(force: forceRefresh),
        userPlaysFuture,
      ]);

      final todas = results[0] as List<Map<String, dynamic>>;
      final networkUserPlays =
          results[1] as Map<String, Map<String, dynamic>>;

      // Algunas APIs legacy devuelven {} ante fallos temporales. Si ya existe
      // una copia privada para esta cuenta, no hacemos desaparecer sus
      // internacionales de Recientes/Historial.
      final usedCachedPlays =
          networkUserPlays.isEmpty && cachedPlays.isNotEmpty;
      final effectiveUserPlays = networkUserPlays.isNotEmpty
          ? networkUserPlays
          : cachedPlays;

      if (networkUserPlays.isNotEmpty) {
        await CacheService.setJson(playsCacheKey, networkUserPlays);
      }

      final finalLoterias = todas.where(_hasRecordedDraw).toList()
        ..sort((a, b) => _lastDrawDate(b).compareTo(_lastDrawDate(a)));

      if (!mounted) return;

      // Si la red falló y _obtenerTodasLasLoterias devolvió el catálogo stale,
      // lo mantenemos visible y lo marcamos. Si no pudo devolver nada pero la
      // pantalla ya estaba hidratada, tampoco se borra.
      if (finalLoterias.isEmpty && _loterias.isNotEmpty) {
        setState(() {
          _userCountry = uCountry;
          _userCountryId = uCountryId;
          _setPlayedRoutes(effectiveUserPlays);
          _filteredLoterias = _filterBySelectedView(_loterias);
          _isLoading = false;
          _loadFailed = false;
          _showingStaleData =
              _catalogFetchFailed || userPlaysFailed || usedCachedPlays;
        });
        return;
      }

      setState(() {
        _userCountry = uCountry;
        _userCountryId = uCountryId;
        _setPlayedRoutes(effectiveUserPlays);
        _loterias = finalLoterias;
        _filteredLoterias = _filterBySelectedView(finalLoterias);
        _isLoading = false;
        _loadFailed = finalLoterias.isEmpty && _catalogFetchFailed;
        _showingStaleData =
            finalLoterias.isNotEmpty &&
            (_catalogFetchFailed || userPlaysFailed || usedCachedPlays);
      });

      if (finalLoterias.isNotEmpty && !_catalogFetchFailed) {
        await CacheService.setJson(cacheKey, finalLoterias);
      }
      if (!_catalogFetchFailed) {
        DataRefreshManager.instance.markUpdated(RefreshModules.resultados);
        DataRefreshManager.instance.markUpdated(RefreshModules.loterias);
        if (forceRefresh) {
          DataRefreshManager.instance.requestRefresh(RefreshModules.loterias);
        }
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _loadFailed = _loterias.isEmpty;
        _showingStaleData = _loterias.isNotEmpty;
      });
    }
  }

  Future<List<Map<String, dynamic>>> _obtenerTodasLasLoterias({
    bool force = false,
  }) async {
    _catalogFetchFailed = false;

    if (!force) {
      final cachedMapeo = await CacheService.getJson(
        CacheService.catalogoLoteriasKey,
      );
      final cachedPaises = await CacheService.getJson('paises_list_cache');
      if (cachedPaises is List && cachedPaises.isNotEmpty) {
        _paises = List<Map<String, dynamic>>.from(cachedPaises);
      }
      if (cachedMapeo is List && cachedMapeo.isNotEmpty) {
        return List<Map<String, dynamic>>.from(cachedMapeo);
      }
    }

    var loteriasNetworkFailure = false;
    try {
      final results = await Future.wait([
        ApiService.getPaises().catchError((_) {
          return <Map<String, dynamic>>[];
        }),
        ApiService.getAllLoterias(
          forceRefresh: force,
        ).catchError((_) {
          loteriasNetworkFailure = true;
          return <dynamic>[];
        }),
      ]);

      final paisesRaw = results[0] as List<Map<String, dynamic>>;
      if (paisesRaw.isNotEmpty) {
        _paises = paisesRaw;
        await CacheService.setJson('paises_list_cache', _paises);
      } else if (_paises.isEmpty) {
        final stalePaises = await CacheService.getStaleJson(
          'paises_list_cache',
        );
        if (stalePaises is List && stalePaises.isNotEmpty) {
          _paises = List<Map<String, dynamic>>.from(stalePaises);
        }
      }

      final loteriasRaw = results[1];
      final List<Map<String, dynamic>> todas = loteriasRaw
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();

      _catalogFetchFailed = loteriasNetworkFailure;

      if (todas.isNotEmpty) {
        await CacheService.setJson(CacheService.catalogoLoteriasKey, todas);
        return todas;
      }

      if (loteriasNetworkFailure) {
        final staleCatalog = await CacheService.getStaleJson(
          CacheService.catalogoLoteriasKey,
        );
        if (staleCatalog is List && staleCatalog.isNotEmpty) {
          return List<Map<String, dynamic>>.from(staleCatalog);
        }
      }
      return todas;
    } catch (_) {
      _catalogFetchFailed = true;
      final staleCatalog = await CacheService.getStaleJson(
        CacheService.catalogoLoteriasKey,
      );
      if (staleCatalog is List && staleCatalog.isNotEmpty) {
        return List<Map<String, dynamic>>.from(staleCatalog);
      }
      return <Map<String, dynamic>>[];
    }
  }

  String? _lastDrawRaw(Map<String, dynamic> loteria) {
    final raw = loteria['ultimo_sorteo'] ?? loteria['fecha_ultimo_sorteo'];
    final value = raw?.toString().trim();
    return value == null || value.isEmpty ? null : value;
  }

  /// `ultimo_sorteo` se calcula en backend sólo con filas de resultados
  /// oficiales. Un próximo sorteo o una predicción nunca habilitan la tarjeta.
  bool _hasRecordedDraw(Map<String, dynamic> loteria) =>
      _lastDrawRaw(loteria) != null;

  String _routeOf(Map<String, dynamic> loteria) {
    final rawRoute = loteria['route']?.toString().trim().toLowerCase();
    if (rawRoute != null && rawRoute.isNotEmpty) return rawRoute;
    return loteria['nombre']
        .toString()
        .trim()
        .toLowerCase()
        .replaceAll(RegExp(r'[áàäâ]'), 'a')
        .replaceAll(RegExp(r'[éèëê]'), 'e')
        .replaceAll(RegExp(r'[íìïî]'), 'i')
        .replaceAll(RegExp(r'[óòöô]'), 'o')
        .replaceAll(RegExp(r'[úùüû]'), 'u')
        .replaceAll(RegExp(r'[ñ]'), 'n')
        .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
        .replaceAll(RegExp(r'^_|_$'), '');
  }

  void _setPlayedRoutes(Map<String, Map<String, dynamic>> userPlays) {
    _activePlayedRoutes = <String>{};
    _pastPlayedRoutes = <String>{};
    _activePlayedLotteryIds = <String>{};
    _pastPlayedLotteryIds = <String>{};

    for (final entry in userPlays.entries) {
      final info = entry.value;
      final route = (info['route']?.toString() ??
              (entry.key.startsWith('route:')
                  ? entry.key.substring('route:'.length)
                  : (int.tryParse(entry.key) == null ? entry.key : '')))
          .trim()
          .toLowerCase();
      final loteriaId = (info['loteria_id']?.toString() ??
              (int.tryParse(entry.key) != null ? entry.key : ''))
          .trim();
      final drawDate = info['fecha']?.toString();
      final dayDifference = _drawDayDifference(drawDate);
      final isActive =
          dayDifference != null &&
          dayDifference >= -_recentGraceDaysAfterDraw;

      if (loteriaId.isNotEmpty) {
        (isActive ? _activePlayedLotteryIds : _pastPlayedLotteryIds)
            .add(loteriaId);
      } else if (route.isNotEmpty) {
        (isActive ? _activePlayedRoutes : _pastPlayedRoutes).add(route);
      }
    }
  }

  bool _isFromUserCountry(Map<String, dynamic> loteria) {
    final countryId = loteria['pais_id']?.toString();
    if (_userCountryId != null && _userCountryId!.isNotEmpty) {
      return countryId == _userCountryId;
    }
    return _getPaisNombre(loteria['pais_id']).trim().toLowerCase() ==
        (_userCountry ?? '').trim().toLowerCase();
  }

  int? _drawDayDifference(String? fecha) {
    if (fecha == null || fecha.trim().isEmpty) return null;
    final clean = fecha.trim();
    final parsed = DateTime.tryParse(clean) ??
        (clean.length >= 10 ? DateTime.tryParse(clean.substring(0, 10)) : null);
    if (parsed == null) return null;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final drawDay = DateTime(parsed.year, parsed.month, parsed.day);
    return drawDay.difference(today).inDays;
  }

  List<Map<String, dynamic>> _filterBySelectedView(
    List<Map<String, dynamic>> source,
  ) {
    final routeCounts = <String, int>{};
    for (final lot in source) {
      final route = _routeOf(lot);
      routeCounts[route] = (routeCounts[route] ?? 0) + 1;
    }

    bool matchesPlay(
      Map<String, dynamic> lot,
      Set<String> ids,
      Set<String> legacyRoutes,
    ) {
      final id = lot['id']?.toString();
      if (id != null && ids.contains(id)) return true;
      final route = _routeOf(lot);
      // Un route legacy compartido no identifica el país y por tanto no debe
      // expandirse a todas las tarjetas de Euromillions/EuroDreams.
      return (routeCounts[route] ?? 0) == 1 && legacyRoutes.contains(route);
    }

    if (_selectedFilter == 'historial') {
      return source
          .where((lot) =>
              !_isFromUserCountry(lot) &&
              matchesPlay(lot, _pastPlayedLotteryIds, _pastPlayedRoutes))
          .toList();
    }
    return source
        .where((lot) =>
            _isFromUserCountry(lot) ||
            matchesPlay(lot, _activePlayedLotteryIds, _activePlayedRoutes))
        .toList();
  }

  void _selectView(String view) {
    if (_selectedFilter == view) return;
    setState(() {
      _selectedFilter = view;
      _filteredLoterias = _filterBySelectedView(_loterias);
    });
  }

  DateTime _lastDrawDate(Map<String, dynamic> loteria) {
    final raw = _lastDrawRaw(loteria);
    if (raw == null) return DateTime.fromMillisecondsSinceEpoch(0);
    return DateTime.tryParse(raw) ??
        (raw.length >= 10
            ? DateTime.tryParse(raw.substring(0, 10))
            : null) ??
        DateTime.fromMillisecondsSinceEpoch(0);
  }

  String _getPaisNombre(dynamic id) {
    if (_paises.isEmpty) {
      return _userCountry ?? "Internacional";
    }
    final p = _paises.firstWhere(
      (p) => p["id"].toString() == id.toString(), 
      orElse: () => {"nombre": _userCountry ?? "Internacional"}
    );
    return p["nombre"] ?? (_userCountry ?? "Internacional");
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Scaffold(
      backgroundColor: AppColors.blackfondo,
      body: SafeArea(
        child: RefreshIndicator(
          color: AppColors.yellow,
          backgroundColor: const Color(0xFF1E1E1E),
          displacement: 25.0,
          onRefresh: () => cargarLoterias(forceRefresh: true),
          child: CustomScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          l10n?.analisisYResultados ??
                              "Análisis y Resultados",
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Consumer<SubscriptionProvider>(
                        builder: (_, sub, __) => PremiumCrownIcon(
                          isPremium: sub.isPremium,
                          size: 22,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: _buildInfoBanner(l10n),
              ),
              SliverToBoxAdapter(
                child: _buildFilterToggleButtons(l10n),
              ),
              if (_showingStaleData)
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(16, 2, 16, 10),
                    child: AppStaleDataBanner(),
                  ),
                ),
              if (_isLoading && _loterias.isEmpty)
                _buildSliverSkeletonList()
              else if (_loadFailed && _loterias.isEmpty)
                SliverToBoxAdapter(
                  child: AppDataStateCard(
                    isConnectionError: true,
                    onRetry: () => cargarLoterias(forceRefresh: true),
                    retrying: _isLoading,
                    margin: const EdgeInsets.fromLTRB(16, 12, 16, 20),
                  ),
                )
              else if (_filteredLoterias.isEmpty)
                SliverToBoxAdapter(
                  child: _buildEmptyState(l10n),
                )
              else
                _buildSliverLotteryList(l10n),
              const SliverToBoxAdapter(
                child: SizedBox(height: 20),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoBanner(AppLocalizations? l10n) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16.0, 30.0, 16.0, 40.0),
      padding: const EdgeInsets.all(14.0),
      decoration: BoxDecoration(
        color: const Color(0xFF141A1E),
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(color: Colors.amber.withValues(alpha: 0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: Colors.amber.withValues(alpha: 0.15),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.info_outline,
                        color: Colors.amber,
                        size: 14,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        l10n?.analisisYResultados ??
                            "Análisis y Resultados",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.montserrat(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  l10n?.descripcionResultadosBanner ??
                      "Aquí encontrarás los últimos resultados oficiales, el historial de sorteos y el análisis de predicciones de cada lotería",
                  style: GoogleFonts.montserrat(
                    fontSize: 12,
                    color: Colors.white.withValues(alpha: 0.9),
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterToggleButtons(AppLocalizations? l10n) {
    final showingRecent = _selectedFilter == 'recientes';
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
      child: Row(
        children: [
          Expanded(
            child: _buildFilterButton(
              isSelected: showingRecent,
              icon: Icons.access_time_rounded,
              label: l10n?.resultadosRecientes ?? 'Recientes',
              onTap: () => _selectView('recientes'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildFilterButton(
              isSelected: !showingRecent,
              icon: Icons.history_rounded,
              label: l10n?.historicoResultadosTitulo ??
                  'Historial de resultados',
              onTap: () => _selectView('historial'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterButton({
    required bool isSelected,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    final foreground = isSelected ? Colors.black : Colors.white70;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        height: 46,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.yellow : const Color(0xFF1E1E1E),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? AppColors.yellow : Colors.white12,
          ),
        ),
        child: Center(
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, size: 17, color: foreground),
                const SizedBox(width: 6),
                Text(
                  label,
                  maxLines: 1,
                  style: GoogleFonts.montserrat(
                    fontSize: 12.5,
                    fontWeight: FontWeight.bold,
                    color: foreground,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState(AppLocalizations? l10n) {
    final showingHistory = _selectedFilter == 'historial';
    final String titleText = showingHistory
        ? (l10n?.sinHistorialResultados ?? 'Aún no hay resultados históricos')
        : (l10n?.sinResultadosRegistrados ??
              'Aún no hay resultados registrados');
    final String bodyText = showingHistory
        ? (l10n?.sinHistorialResultadosDescripcion ??
              'Los sorteos anteriores aparecerán aquí cuando cada lotería tenga más de un resultado oficial.')
        : (l10n?.sinResultadosRegistradosDescripcion ??
              'Las loterías aparecerán aquí cuando registren su primer sorteo oficial.');

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 24.0),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white10, width: 1),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.yellow.withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(
              showingHistory
                  ? Icons.history_toggle_off_rounded
                  : Icons.public_outlined,
              color: AppColors.yellow,
              size: 38,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            titleText,
            style: AppTextStyles.h2.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Text(
            bodyText,
            style: AppTextStyles.mensajeSecundario.copyWith(
              color: Colors.white54,
              fontSize: 13,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildSliverLotteryList(AppLocalizations? l10n) {


    final grouped = <String, List<Map<String, dynamic>>>{};
    final langCode = Localizations.localeOf(context).languageCode;

    for (var lot in _filteredLoterias) {
      final pNombre = _getPaisNombre(lot["pais_id"]);
      grouped.putIfAbsent(pNombre, () => []).add(lot);
    }

    final sortedCountries = grouped.keys.toList()
      ..sort((a, b) {
        if (a == _userCountry) return -1;
        if (b == _userCountry) return 1;
        return a.compareTo(b);
      });

    final List<Widget> sliverItems = [];
    for (var country in sortedCountries) {
      final lots = grouped[country]!;
      final countryDisplay = PaisHelper.getNombreTraducido(country, langCode);

      sliverItems.add(
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
          child: Row(
            children: [
              Text(PaisHelper.getBanderaEmoji(country), style: const TextStyle(fontSize: 18)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  countryDisplay,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.h2.copyWith(
                    color: AppColors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      );

      for (var loteria in lots) {
        sliverItems.add(_buildLotteryItem(loteria, l10n));
      }
    }

    sliverItems.add(const SizedBox(height: 20));

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) => sliverItems[index],
        childCount: sliverItems.length,
      ),
    );
  }

  String _formatearFechaSimple(String? fecha) {
    if (fecha == null || fecha.isEmpty) return "";
    try {
      final clean = fecha.trim();
      final parsed = DateTime.tryParse(clean) ?? (clean.length >= 10 ? DateTime.tryParse(clean.substring(0, 10)) : null);
      if (parsed == null) return fecha;

      final langCode = Localizations.localeOf(context).languageCode;
      final dias = langCode == 'en'
          ? ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
          : (langCode == 'pt'
              ? ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"]
              : (langCode == 'fr'
                  ? ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"]
                  : ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]));

      final meses = langCode == 'en'
          ? ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
          : (langCode == 'pt'
              ? ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]
              : (langCode == 'fr'
                  ? ["Jan", "Fév", "Mar", "Avr", "Mai", "Juin", "Juil", "Aoû", "Sep", "Oct", "Nov", "Déc"]
                  : ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]));

      final diaSemana = dias[parsed.weekday - 1];
      final mes = meses[parsed.month - 1];

      return "$diaSemana, ${parsed.day} $mes ${parsed.year}";
    } catch (_) {
      return fecha;
    }
  }

  String _calcularEstadoSorteo(String? fecha) {
    if (fecha == null || fecha.isEmpty) return "";
    try {
      final clean = fecha.trim();
      final parsed = DateTime.tryParse(clean) ?? (clean.length >= 10 ? DateTime.tryParse(clean.substring(0, 10)) : null);
      if (parsed == null) return "";

      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);
      final target = DateTime(parsed.year, parsed.month, parsed.day);
      final diff = target.difference(today).inDays;

      final langCode = Localizations.localeOf(context).languageCode;

      if (diff == 0) {
        if (langCode == 'en') return "Draws today";
        if (langCode == 'pt') return "Sorteia hoje";
        if (langCode == 'fr') return "Tirage aujourd’hui";
        return "Sortea hoy";
      } else if (diff == 1) {
        if (langCode == 'en') return "Tomorrow";
        if (langCode == 'pt') return "Amanhã";
        if (langCode == 'fr') return "Demain";
        return "Mañana";
      } else if (diff > 1) {
        if (langCode == 'en') return "In $diff days";
        if (langCode == 'pt') return "Faltam $diff dias";
        if (langCode == 'fr') return "Dans $diff jours";
        return "Faltan $diff días";
      } else if (diff == -1) {
        if (langCode == 'en') return "Drew yesterday";
        if (langCode == 'pt') return "Sorteado ontem";
        if (langCode == 'fr') return "Tiré hier";
        return "Sorteó ayer";
      } else {
        final dias = diff.abs();
        if (langCode == 'en') return "Drew $dias days ago";
        if (langCode == 'pt') return "Sorteado há $dias dias";
        if (langCode == 'fr') return "Tiré il y a $dias jours";
        return "Sorteó hace $dias días";
      }
    } catch (_) {
      return "";
    }
  }

  Widget _buildLotteryItem(Map<String, dynamic> loteria, AppLocalizations? l10n) {
    final nombre = loteria["nombre"] ?? "";
    final String nombreFormateado = nombre.isNotEmpty
        ? nombre[0].toUpperCase() + nombre.substring(1).toLowerCase()
        : "";
    final rawFecha = _lastDrawRaw(loteria);
    final fechaDisplay = _formatearFechaSimple(rawFecha);
    final estadoDisplay = _calcularEstadoSorteo(rawFecha);
    final openingHistory = _selectedFilter == 'historial';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 3.5),
      child: Material(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(10),
        clipBehavior: Clip.antiAlias,
        child: ListTile(
        dense: true,
        visualDensity: const VisualDensity(horizontal: 0, vertical: -2),
        // El filtro Historial sólo cambia la lista; entrar en una lotería no
        // debe abrir ni el historial completo ni el anuncio automáticamente.
        onTap: () => _navigateToEstadisticas(loteria),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 0.0),
        leading: LotteryAvatar3D(nombre: nombre, size: 36),
        title: Text(
          nombreFormateado,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: AppTextStyles.h2.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.w600,
            fontSize: 14.5,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 2),
            Text(
              fechaDisplay,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 11.5,
                fontWeight: FontWeight.w500,
              ),
              overflow: TextOverflow.ellipsis,
            ),
            if (estadoDisplay.isNotEmpty) ...[
              const SizedBox(height: 2),
              Text(
                estadoDisplay,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white38,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ],
        ),
        trailing: openingHistory
            ? const Icon(
                Icons.history_rounded,
                color: AppColors.yellow,
                size: 18,
              )
            : const Icon(
                Icons.analytics_outlined,
                color: AppColors.yellow,
                size: 18,
              ),
        ),
      ),
    );
  }

  void _navigateToEstadisticas(Map<String, dynamic> loteria) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ResultadosDashboardScreen(
          loteriaNombreInicial: loteria["nombre"] ?? "Lotería",
          loteriaData: loteria,
        ),
      ),
    );
  }

  Widget _buildSliverSkeletonList() {
    return SliverToBoxAdapter(
      child: Shimmer.fromColors(
        baseColor: const Color(0xFF1A1A1A),
        highlightColor: const Color(0xFF2C2C2C),
        period: const Duration(milliseconds: 1400),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            children: List.generate(
              6,
              (index) => Container(
                margin: const EdgeInsets.only(bottom: 12),
                height: 72,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
