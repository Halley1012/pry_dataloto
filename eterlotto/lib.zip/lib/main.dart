import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:eterlotto/screens/welcome.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'screens/home.dart';
import 'screens/login.dart';
import 'screens/registro.dart';
import 'screens/splash_screen.dart';
import 'screens/notifications_screen.dart';
import 'styles/colores.dart';
import 'styles/app_text_styles.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:eterlotto/l10n/generated/app_localizations.dart';

import 'providers/locale_provider.dart';
import 'providers/notification_provider.dart';
import 'providers/subscription_provider.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'screens/estadisticas_dashboard_screen.dart';
import 'screens/subscription_screen.dart';
import 'package:eterlotto/services/push_notification_service.dart';
import 'package:eterlotto/services/ad_service.dart';
import 'package:eterlotto/services/data_refresh_manager.dart';
import 'package:eterlotto/config/navigation.dart';

// Provider de Idioma global. navigatorKey vive en config/navigation.dart
final LocaleProvider localeProvider = LocaleProvider();

void main() {
  // Las trazas detalladas se conservan durante el desarrollo, pero ninguna
  // información de diagnóstico se escribe en la consola de una app publicada.
  if (kReleaseMode) {
    debugPrint = (String? message, {int? wrapWidth}) {};
  }

  runZonedGuarded(
    () async {
      // Inicializar bindings y configuraciones dentro de la misma zona
      WidgetsFlutterBinding.ensureInitialized();

      // Inicializar gestor central de ciclo de vida y refresco inteligente.
      // No usamos await porque initialize() en tu implementación actual
      // se ejecuta como inicialización en segundo plano.
      DataRefreshManager.instance.initialize();

      // Bloquear la app en vertical
      await SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ]);

      // Iniciar la aplicación inmediatamente
      runApp(const EterlottoApp());

      // Inicializar Notificaciones Push y Firebase en segundo plano
      unawaited(PushNotificationService.initialize());

      // Inicializar Google Mobile Ads en segundo plano
      unawaited(AdService.instance.initialize());
    },
    (error, stackTrace) {
      // Los 401 se resuelven de forma centralizada en ApiService:
      // refresh silencioso o, sólo si el refresh expiró, sesión vencida.
      //
      // No navegar por coincidencias de texto desde el manejador global,
      // ya que un error ajeno a autenticación podría contener "401".
      debugPrint('[APP] Unhandled error: ${error.runtimeType}');
    },
  );
}

class EterlottoApp extends StatelessWidget {
  const EterlottoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(
          value: localeProvider,
        ),
        ChangeNotifierProvider(
          create: (_) => NotificationProvider(),
        ),
        ChangeNotifierProvider(
          create: (_) => SubscriptionProvider(),
        ),
      ],
      child: _AdLifecycleBridge(
        child: ListenableBuilder(
          listenable: localeProvider,
          builder: (context, _) {
            return MaterialApp(
            navigatorKey: navigatorKey,
            debugShowCheckedModeBanner: false,
            initialRoute: '/splash',
            title: 'Eterlotto',

            // Mantiene la interfaz legible con la escala de accesibilidad del
            // dispositivo, sin permitir que una escala extrema rompa filas o
            // tarjetas que ya se adaptan a cualquier idioma/país.
            builder: (context, child) {
              final mediaQuery = MediaQuery.of(context);

              return MediaQuery(
                data: mediaQuery.copyWith(
                  textScaler: mediaQuery.textScaler.clamp(
                    maxScaleFactor: 1.15,
                  ),
                ),
                child: child ?? const SizedBox.shrink(),
              );
            },

            locale: localeProvider.locale,

            localizationsDelegates: [
              AppLocalizations.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],

            supportedLocales: AppLocalizations.supportedLocales,

            localeResolutionCallback: (
              deviceLocale,
              supportedLocales,
            ) {
              if (localeProvider.locale != null) {
                return localeProvider.locale;
              }

              if (deviceLocale != null) {
                for (final supportedLocale in supportedLocales) {
                  if (supportedLocale.languageCode ==
                      deviceLocale.languageCode) {
                    return supportedLocale;
                  }
                }
              }

              // Fallback por defecto: Español
              return const Locale('es');
            },

            theme: ThemeData.dark().copyWith(
              textTheme: GoogleFonts.montserratTextTheme(
                ThemeData.dark().textTheme,
              ),
              primaryColor: Colors.deepPurple,
              scaffoldBackgroundColor: AppColors.blackfondo,
              canvasColor: AppColors.blackfondo,
              cardColor: AppColors.darkGray,

              colorScheme: const ColorScheme.dark(
                primary: Colors.deepPurple,
                surface: AppColors.blackfondo,
              ),

              pageTransitionsTheme: PageTransitionsTheme(
                builders: {
                  TargetPlatform.android:
                      FadeUpwardsPageTransitionsBuilder(),
                  TargetPlatform.iOS:
                      CupertinoPageTransitionsBuilder(),
                },
              ),

              snackBarTheme: SnackBarThemeData(
                backgroundColor: AppColors.amber,
                contentTextStyle:
                    AppTextStyles.mensajeImportante.copyWith(
                  color: const Color(0xFF1E1E1E),
                ),
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),

              inputDecorationTheme: InputDecorationTheme(
                filled: true,
                fillColor: const Color(0xFF1E1E24),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 16,
                ),
                labelStyle: GoogleFonts.montserrat(
                  color: Colors.white60,
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
                hintStyle: GoogleFonts.montserrat(
                  color: Colors.white38,
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
                floatingLabelStyle: GoogleFonts.montserrat(
                  color: AppColors.yellow,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: const BorderSide(
                    color: Colors.white12,
                    width: 1.0,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: const BorderSide(
                    color: Colors.white12,
                    width: 1.0,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: const BorderSide(
                    color: AppColors.yellow,
                    width: 1.5,
                  ),
                ),
                errorBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: const BorderSide(
                    color: Colors.redAccent,
                    width: 1.0,
                  ),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: const BorderSide(
                    color: Colors.redAccent,
                    width: 1.5,
                  ),
                ),
              ),
            ),

            routes: {
              '/splash': (context) => const SplashScreen(),
              '/welcome': (context) => const WelcomeScreen(),
              '/login': (context) => const LoginPage(),
              '/home': (context) => const HomeScreen(),
              '/notifications': (context) =>
                  const NotificationsScreen(),
              '/subscription': (context) =>
                  const SubscriptionScreen(),
              '/registro': (context) => const RegistroScreen(),
            },

            onGenerateRoute: (settings) {
              final name = settings.name ?? '';

              if (name == '/registro') {
                final args =
                    settings.arguments as Map<String, dynamic>?;

                return MaterialPageRoute(
                  builder: (_) => RegistroScreen(
                    user: args?['user'] as Map<String, dynamic>?,
                    userId: args?['userId'] as int?,
                    isSocialOnboarding:
                        args?['isSocialOnboarding'] as bool? ?? false,
                  ),
                );
              }

              if (name.startsWith('/estadisticas_')) {
                final loteriaKey =
                    name.replaceFirst('/estadisticas_', '');

                return MaterialPageRoute(
                  builder: (_) =>
                      EstadisticasDashboardScreen(
                    loteriaNombreInicial: loteriaKey,
                    loteriaRoute: loteriaKey,
                  ),
                );
              }

              return null;
            },
            );
          },
        ),
      ),
    );
  }
}

class _AdLifecycleBridge extends StatefulWidget {
  final Widget child;

  const _AdLifecycleBridge({required this.child});

  @override
  State<_AdLifecycleBridge> createState() => _AdLifecycleBridgeState();
}

class _AdLifecycleBridgeState extends State<_AdLifecycleBridge>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final subscription = context.read<SubscriptionProvider>();
      AdService.instance.onAppForegrounded(
        isPremium: subscription.isPremium,
      );
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.hidden) {
      AdService.instance.onAppBackgrounded();
      return;
    }

    if (state == AppLifecycleState.resumed) {
      final subscription = context.read<SubscriptionProvider>();
      AdService.instance.onAppForegrounded(
        isPremium: subscription.isPremium,
      );
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}