import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Fondo Premium nativo: seda dorada, destellos y profundidad sin imágenes pesadas.
///
/// Diseñado para colocarse dentro de un [Stack] detrás del encabezado de la app.
/// El ciclo es de 7 segundos con curvas suaves (`Curves.easeInOut`), produciendo
/// un desplazamiento sutil y relajante tipo seda dorada.
/// Los destellos son estrellas limpias de 4 puntas (✦) con fade y escala muy pequeña,
/// sin halos circulares visibles.
class PremiumHeaderBackground extends StatefulWidget {
  final double? height;

  const PremiumHeaderBackground({
    super.key,
    this.height,
  });

  @override
  State<PremiumHeaderBackground> createState() =>
      _PremiumHeaderBackgroundState();
}

class _PremiumHeaderBackgroundState extends State<PremiumHeaderBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _curvedAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 7),
    )..repeat();

    _curvedAnimation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _curvedAnimation,
      builder: (context, _) {
        return CustomPaint(
          size: widget.height != null
              ? Size(double.infinity, widget.height!)
              : Size.infinite,
          painter: _PremiumGoldenWavesPainter(
            progress: _curvedAnimation.value,
          ),
        );
      },
    );
  }
}

class _PremiumGoldenWavesPainter extends CustomPainter {
  final double progress;

  _PremiumGoldenWavesPainter({required this.progress});

  // Coordenadas relativas de destellos. Se mantienen fuera de textos y controles.
  static const List<Offset> _sparklePositions = [
    Offset(0.18, 0.38),
    Offset(0.67, 0.22),
    Offset(0.86, 0.46),
    Offset(0.52, 0.73),
    Offset(0.93, 0.81),
    Offset(0.11, 0.82),
  ];


  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final waveCycle = progress * 2 * math.pi;

    // Fondo totalmente transparente: el Home conserva su negro original.
    // Para VIP solo quedan los destellos animados.
    for (int i = 0; i < _sparklePositions.length; i++) {
      final pos = _sparklePositions[i];
      final phase = waveCycle + (i * (math.pi / 2.5));
      final rawPulse = (math.sin(phase) + 1.0) / 2.0;
      final opacity = (rawPulse * 0.70).clamp(0.0, 0.70);
      final scale = 6.0 + (rawPulse * 7.0);

      if (opacity > 0.05) {
        _drawCleanFourPointStar(
          canvas,
          Offset(pos.dx * w, pos.dy * h),
          scale,
          opacity,
        );
      }
    }
  }

  /// Dibuja una estrella limpia de 4 puntas (✦) sin halos circulares
  void _drawCleanFourPointStar(
      Canvas canvas, Offset center, double radius, double opacity) {
    final paint = Paint()
      ..color = const Color(0xFFFFF9E0).withValues(alpha: opacity)
      ..style = PaintingStyle.fill;

    final path = Path();
    final arm = radius;
    final inner = radius * 0.15; // Cintura fina y esbelta para que las 4 puntas sean bien definidas

    // Construcción de la estrella de 4 puntas con curvas cóncavas
    path.moveTo(center.dx, center.dy - arm);
    path.quadraticBezierTo(center.dx, center.dy - inner, center.dx + inner, center.dy);
    path.quadraticBezierTo(center.dx + inner, center.dy, center.dx + arm, center.dy);
    path.quadraticBezierTo(center.dx + inner, center.dy, center.dx, center.dy + inner);
    path.quadraticBezierTo(center.dx, center.dy + inner, center.dx, center.dy + arm);
    path.quadraticBezierTo(center.dx, center.dy + inner, center.dx - inner, center.dy);
    path.quadraticBezierTo(center.dx - inner, center.dy, center.dx - arm, center.dy);
    path.quadraticBezierTo(center.dx - inner, center.dy, center.dx, center.dy - inner);
    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _PremiumGoldenWavesPainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}
