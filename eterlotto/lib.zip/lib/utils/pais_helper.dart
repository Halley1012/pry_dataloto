import 'package:flutter/material.dart';

class PaisHelper {
  static String getBanderaEmoji(String nombre) {
    final n = nombre.toLowerCase().trim();
    if (n.contains("estados unidos") || n.contains("usa") || n.contains("eeuu") || n.contains("ee.uu") || n.contains("united states")) {
      return "🇺🇸";
    }
    if (n.contains("españa") || n.contains("espana") || n.contains("spain")) {
      return "🇪🇸";
    }
    if (n.contains("méxico") || n.contains("mexico")) {
      return "🇲🇽";
    }
    if (n.contains("brasil") || n.contains("brazil")) {
      return "🇧🇷";
    }
    if (n.contains("argentina")) {
      return "🇦🇷";
    }
    if (n.contains("colombia")) {
      return "🇨🇴";
    }
    if (n.contains("perú") || n.contains("peru")) {
      return "🇵🇪";
    }
    if (n.contains("chile")) {
      return "🇨🇱";
    }
    if (n.contains("venezuela")) {
      return "🇻🇪";
    }
    if (n.contains("ecuador")) {
      return "🇪🇨";
    }
    if (n.contains("bolivia")) {
      return "🇧🇴";
    }
    if (n.contains("uruguay")) {
      return "🇺🇾";
    }
    if (n.contains("paraguay")) {
      return "🇵🇾";
    }
    if (n.contains("panamá") || n.contains("panama")) {
      return "🇵🇦";
    }
    if (n.contains("costa rica")) {
      return "🇨🇷";
    }
    if (n.contains("guatemala")) {
      return "🇬🇹";
    }
    if (n.contains("dominicana")) {
      return "🇩🇴";
    }
    if (n.contains("puerto rico")) {
      return "🇵🇷";
    }
    if (n.contains("canadá") || n.contains("canada")) {
      return "🇨🇦";
    }
    if (n.contains("reino unido") || n.contains("inglaterra") || n.contains("uk")) {
      return "🇬🇧";
    }
    if (n.contains("francia") || n.contains("france")) {
      return "🇫🇷";
    }
    if (n.contains("italia") || n.contains("italy")) {
      return "🇮🇹";
    }
    if (n.contains("alemania") || n.contains("germany")) {
      return "🇩🇪";
    }
    if (n.contains("irlanda") || n.contains("ireland")) {
      return "🇮🇪";
    }
    if (n.contains("luxemburgo") || n.contains("luxembourg")) {
      return "🇱🇺";
    }
    if (n.contains("bélgica") || n.contains("belgica") || n.contains("belgium")) {
      return "🇧🇪";
    }
    if (n.contains("austria") || n.contains("áustria")) {
      return "🇦🇹";
    }
    if (n.contains("portugal")) {
      return "🇵🇹";
    }
    if (n.contains("suiza") || n.contains("suíça") || n.contains("switzerland")) {
      return "🇨🇭";
    }
    if (n == "todos") {
      return "🌐";
    }
    return "🌐";
  }

  static String getIsoCode(String nombre) {
    final n = nombre.toLowerCase().trim();
    if (n.contains("estados unidos") || n.contains("usa") || n.contains("eeuu") || n.contains("ee.uu") || n.contains("united states")) {
      return "US";
    }
    if (n.contains("españa") || n.contains("espana") || n.contains("spain")) return "ES";
    if (n.contains("méxico") || n.contains("mexico")) return "MX";
    if (n.contains("brasil") || n.contains("brazil")) return "BR";
    if (n.contains("argentina")) return "AR";
    if (n.contains("colombia")) return "CO";
    if (n.contains("perú") || n.contains("peru")) return "PE";
    if (n.contains("chile")) return "CL";
    if (n.contains("venezuela")) return "VE";
    if (n.contains("ecuador")) return "EC";
    if (n.contains("bolivia")) return "BO";
    if (n.contains("uruguay")) return "UY";
    if (n.contains("paraguay")) return "PY";
    if (n.contains("panamá") || n.contains("panama")) return "PA";
    if (n.contains("costa rica")) return "CR";
    if (n.contains("guatemala")) return "GT";
    if (n.contains("dominicana")) return "DO";
    if (n.contains("puerto rico")) return "PR";
    if (n.contains("canadá") || n.contains("canada")) return "CA";
    if (n.contains("reino unido") || n.contains("inglaterra") || n.contains("uk")) return "GB";
    if (n.contains("francia") || n.contains("france")) return "FR";
    if (n.contains("italia") || n.contains("italy")) return "IT";
    if (n.contains("alemania") || n.contains("germany")) return "DE";
    if (n.contains("irlanda") || n.contains("ireland")) return "IE";
    if (n.contains("luxemburgo") || n.contains("luxembourg")) return "LU";
    if (n.contains("bélgica") || n.contains("belgica") || n.contains("belgium")) return "BE";
    if (n.contains("austria") || n.contains("áustria")) return "AT";
    if (n.contains("portugal")) return "PT";
    if (n.contains("suiza") || n.contains("suíça") || n.contains("switzerland")) return "CH";
    if (n.contains("honduras")) return "HN";
    if (n.contains("el salvador")) return "SV";
    if (n.contains("nicaragua")) return "NI";
    if (n.contains("europa") || n.contains("europe") || n.contains("euromillones") || n.contains("euromillions") || n.contains("eurodreams")) return "EU";
    return "CO";
  }

  static String getPaisNameByRoute(String? routeOrName) {
    final r = (routeOrName ?? "").toLowerCase().trim();
    if (r.contains("5deoro") || r.contains("cincodeoro") || r.contains("uruguay")) return "Uruguay";
    if (r.contains("bloto") || r.contains("baloto") || r.contains("mloto") || r.contains("miloto") || r.contains("cloto") || r.contains("colorloto") || r.contains("colombia")) return "Colombia";
    if (r.contains("melate") || r.contains("chispazo") || r.contains("mexico") || r.contains("méxico") || r.contains("tris")) return "México";
    if (r.contains("latinka") || r.contains("tinka") || r.contains("kabala") || r.contains("ganadiario") || r.contains("peru") || r.contains("perú")) return "Perú";
    if (r.contains("megasena") || r.contains("quina") || r.contains("duplasena") || r.contains("maismilionaria") || r.contains("brasil") || r.contains("brazil") || r.contains("lotofacil")) return "Brasil";
    // Estas loterías son compartidas entre varios países. La ruta identifica
    // el juego/motor, no el país concreto. "Europa" queda solo como fallback.
    if (r.contains("euromillones") || r.contains("euromillions") || r.contains("eurodreams") || r.contains("eurojackpot")) return "Europa";
    if (r.contains("primitiva") || r.contains("bonoloto") || r.contains("el_gordo") || r.contains("gordo") || r.contains("espana") || r.contains("españa") || r.contains("spain")) return "España";
    if (r.contains("powerball") || r.contains("megamillions") || r.contains("lotto_america") || r.contains("double_play") || r.contains("millionaire_life") || r.contains("usa") || r.contains("eeuu") || r.contains("united_states") || r.contains("cash4life")) return "Estados Unidos";
    if (r.contains("argentina") || r.contains("quini6") || r.contains("loto_plus") || r.contains("brinco")) return "Argentina";
    if (r.contains("chile") || r.contains("kino") || r.contains("loto_chile")) return "Chile";
    if (r.contains("lotto_cr") || r.contains("costa_rica") || r.contains("costa rica") || r.contains("nuevos_tiempos") || r.contains("3monazos")) return "Costa Rica";
    if (r.contains("dominicana") || r.contains("leidsa")) return "Dominicana";
    if (r.contains("paraguay")) return "Paraguay";
    if (r.contains("bolivia")) return "Bolivia";
    if (r.contains("reino_unido") || r.contains("uk") || r.contains("national_lottery") || r.contains("thunderball")) return "Reino Unido";
    if (r.contains("francia") || r.contains("loto_fr")) return "Francia";
    if (r.contains("italia") || r.contains("superenalotto")) return "Italia";
    if (r.contains("alemania")) return "Alemania";
    if (r.contains("irlanda") || r.contains("ireland")) return "Irlanda";
    if (r.contains("luxemburgo") || r.contains("luxembourg")) return "Luxemburgo";
    if (r.contains("belgica") || r.contains("bélgica") || r.contains("belgium")) return "Bélgica";
    if (r.contains("austria") || r.contains("áustria")) return "Austria";
    if (r.contains("portugal")) return "Portugal";
    if (r.contains("suiza") || r.contains("suíça") || r.contains("switzerland")) return "Suiza";
    if (r.contains("ecuador") || r.contains("pozo_millonario") || r.contains("lotto_ecuador")) return "Ecuador";
    
    return "";
  }

  static bool isSharedEuropeanLottery(String? routeOrName) {
    final r = (routeOrName ?? "").toLowerCase().trim();
    return r.contains("euromillones") ||
        r.contains("euromillions") ||
        r.contains("eurodreams");
  }

  static String getDialCode(String nombre) {
    final n = nombre.toLowerCase().trim();
    if (n.contains("estados unidos") || n.contains("usa") || n.contains("eeuu") || n.contains("ee.uu") || n.contains("united states")) {
      return "+1";
    }
    if (n.contains("españa") || n.contains("espana") || n.contains("spain")) return "+34";
    if (n.contains("méxico") || n.contains("mexico")) return "+52";
    if (n.contains("brasil") || n.contains("brazil")) return "+55";
    if (n.contains("argentina")) return "+54";
    if (n.contains("colombia")) return "+57";
    if (n.contains("perú") || n.contains("peru")) return "+51";
    if (n.contains("chile")) return "+56";
    if (n.contains("venezuela")) return "+58";
    if (n.contains("ecuador")) return "+593";
    if (n.contains("bolivia")) return "+591";
    if (n.contains("uruguay")) return "+598";
    if (n.contains("paraguay")) return "+595";
    if (n.contains("panamá") || n.contains("panama")) return "+507";
    if (n.contains("costa rica")) return "+506";
    if (n.contains("guatemala")) return "+502";
    if (n.contains("dominicana")) return "+1";
    if (n.contains("puerto rico")) return "+1";
    if (n.contains("canadá") || n.contains("canada")) return "+1";
    if (n.contains("reino unido") || n.contains("inglaterra") || n.contains("uk")) return "+44";
    if (n.contains("francia") || n.contains("france")) return "+33";
    if (n.contains("italia") || n.contains("italy")) return "+39";
    if (n.contains("alemania") || n.contains("germany")) return "+49";
    if (n.contains("irlanda") || n.contains("ireland")) return "+353";
    if (n.contains("luxemburgo") || n.contains("luxembourg")) return "+352";
    if (n.contains("bélgica") || n.contains("belgica") || n.contains("belgium")) return "+32";
    if (n.contains("austria") || n.contains("áustria")) return "+43";
    if (n.contains("portugal")) return "+351";
    if (n.contains("suiza") || n.contains("suíça") || n.contains("switzerland")) return "+41";
    if (n.contains("honduras")) return "+504";
    if (n.contains("el salvador")) return "+503";
    if (n.contains("nicaragua")) return "+505";
    return "+57";
  }

  static String getNombreTraducido(String nombre, String langCode) {
    final n = nombre.toLowerCase().trim();
    if (langCode == 'en') {
      if (n.contains("estados unidos") || n.contains("usa") || n.contains("eeuu") || n.contains("united states")) {
        return "United States";
      }
      if (n.contains("españa") || n.contains("espana")) return "Spain";
      if (n.contains("méxico") || n.contains("mexico")) return "Mexico";
      if (n.contains("brasil")) return "Brazil";
      if (n.contains("alemania")) return "Germany";
      if (n.contains("francia")) return "France";
      if (n.contains("irlanda")) return "Ireland";
      if (n.contains("luxemburgo")) return "Luxembourg";
      if (n.contains("bélgica") || n.contains("belgica")) return "Belgium";
      if (n.contains("austria") || n.contains("áustria")) return "Austria";
      if (n.contains("portugal")) return "Portugal";
      if (n.contains("suiza") || n.contains("suíça")) return "Switzerland";
      if (n.contains("reino unido") || n.contains("inglaterra")) return "United Kingdom";
      if (n == "todos" || n == "internacional") return "International";
    } else if (langCode == 'pt') {
      if (n.contains("estados unidos") || n.contains("usa") || n.contains("eeuu") || n.contains("united states")) {
        return "Estados Unidos";
      }
      if (n.contains("españa") || n.contains("espana")) return "Espanha";
      if (n.contains("méxico") || n.contains("mexico")) return "México";
      if (n.contains("brasil")) return "Brasil";
      if (n.contains("alemania")) return "Alemanha";
      if (n.contains("francia")) return "França";
      if (n.contains("irlanda")) return "Irlanda";
      if (n.contains("luxemburgo")) return "Luxemburgo";
      if (n.contains("bélgica") || n.contains("belgica")) return "Bélgica";
      if (n.contains("austria") || n.contains("áustria")) return "Áustria";
      if (n.contains("portugal")) return "Portugal";
      if (n.contains("suiza") || n.contains("suíça")) return "Suíça";
      if (n.contains("reino unido")) return "Reino Unido";
      if (n == "todos" || n == "internacional") return "Internacional";
    } else if (langCode == 'fr') {
      if (n.contains("estados unidos") || n.contains("usa") || n.contains("eeuu") || n.contains("united states")) return "États-Unis";
      if (n.contains("españa") || n.contains("espana")) return "Espagne";
      if (n.contains("méxico") || n.contains("mexico")) return "Mexique";
      if (n.contains("brasil")) return "Brésil";
      if (n.contains("alemania")) return "Allemagne";
      if (n.contains("francia")) return "France";
      if (n.contains("irlanda")) return "Irlande";
      if (n.contains("luxemburgo")) return "Luxembourg";
      if (n.contains("bélgica") || n.contains("belgica")) return "Belgique";
      if (n.contains("austria") || n.contains("áustria")) return "Autriche";
      if (n.contains("portugal")) return "Portugal";
      if (n.contains("suiza") || n.contains("suíça")) return "Suisse";
      if (n.contains("reino unido") || n.contains("inglaterra")) return "Royaume-Uni";
      if (n == "todos" || n == "internacional") return "International";
    }
    if (nombre.isNotEmpty) {
      return nombre[0].toUpperCase() + nombre.substring(1).toLowerCase();
    }
    return nombre;
  }

  static Widget buildItemConBandera(String nombre, {TextStyle? style}) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          getBanderaEmoji(nombre),
          style: const TextStyle(fontSize: 22),
        ),
        const SizedBox(width: 10),
        Flexible(
          child: Text(
            nombre,
            style: style,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  static String getMonedaByRoute(String? routeOrName, {String? rawText}) {
    final r = (routeOrName ?? "").toLowerCase().trim();
    final raw = (rawText ?? "").trim().toUpperCase();

    // 1. Detección por símbolo o código explícito en el texto
    if (raw.contains("MXN")) return "MXN";
    if (raw.contains("COP")) return "COP";
    if (raw.contains("UYU")) return "UYU";
    if (raw.contains("PEN")) return "PEN";
    if (raw.contains("BRL") || raw.startsWith("R\$")) return "BRL";
    if (raw.contains("EUR") || raw.contains("€")) return "EUR";
    if (raw.contains("USD") || raw.contains("US\$")) return "USD";
    if (raw.contains("ARS")) return "ARS";
    if (raw.contains("CLP")) return "CLP";
    if (raw.contains("PYG")) return "PYG";
    if (raw.contains("CRC") || raw.contains("₡")) return "CRC";
    if (raw.contains("DOP")) return "DOP";
    if (raw.contains("S/")) return "PEN";

    // 2. Detección por país o ruta de la lotería
    if (r.contains("5deoro") || r.contains("cincodeoro") || r.contains("uruguay")) return "UYU";
    if (r.contains("bloto") || r.contains("baloto") || r.contains("mloto") || r.contains("miloto") || r.contains("cloto") || r.contains("colorloto") || r.contains("colombia")) return "COP";
    if (r.contains("melate") || r.contains("chispazo") || r.contains("mexico") || r.contains("méxico")) return "MXN";
    if (r.contains("latinka") || r.contains("tinka") || r.contains("kabala") || r.contains("ganadiario") || r.contains("peru") || r.contains("perú")) return "PEN";
    if (r.contains("megasena") || r.contains("quina") || r.contains("duplasena") || r.contains("maismilionaria") || r.contains("brasil") || r.contains("brazil")) return "BRL";
    if (r.contains("primitiva") || r.contains("bonoloto") || r.contains("el_gordo") || r.contains("gordo") || r.contains("euromillones") || r.contains("euromillions") || r.contains("eurodreams") || r.contains("espana") || r.contains("españa") || r.contains("spain") || r.contains("francia") || r.contains("italia") || r.contains("alemania") || r.contains("irlanda") || r.contains("ireland") || r.contains("luxemburgo") || r.contains("luxembourg") || r.contains("belgica") || r.contains("bélgica") || r.contains("belgium") || r.contains("austria") || r.contains("áustria") || r.contains("portugal") || r.contains("suiza") || r.contains("suíça") || r.contains("switzerland")) return "EUR";
    if (r.contains("powerball") || r.contains("megamillions") || r.contains("lotto_america") || r.contains("double_play") || r.contains("millionaire_life") || r.contains("usa") || r.contains("eeuu") || r.contains("united_states") || r.contains("panama") || r.contains("panamá") || r.contains("ecuador")) return "USD";
    if (r.contains("argentina") || r.contains("quini6") || r.contains("loto_plus")) return "ARS";
    if (r.contains("chile") || r.contains("kino") || r.contains("loto_chile")) return "CLP";
    if (r.contains("lotto_cr") || r.contains("costa_rica") || r.contains("costa rica")) return "CRC";
    if (r.contains("dominicana") || r.contains("leidsa")) return "DOP";
    if (r.contains("paraguay")) return "PYG";
    if (r.contains("bolivia")) return "BOB";
    if (r.contains("reino_unido") || r.contains("uk") || r.contains("national_lottery")) return "GBP";

    return "";
  }

  /// Separa el Jackpot en [valor, etiqueta] (ej: ["$55.200", "millones COP"], ["$48.000.000", "UYU"], ["R$ 87.000.000", "BRL"])
  static Map<String, String> getJackpotParts(String? raw, {String? loteriaRoute, String fallbackValue = ""}) {
    final String text = (raw == null || raw.trim().isEmpty) ? fallbackValue : raw.trim();
    if (text.isEmpty || text == "--") return {"value": fallbackValue.isNotEmpty ? fallbackValue : "--", "label": ""};

    final String defaultCurrency = getMonedaByRoute(loteriaRoute, rawText: text);

    // 1. Normalizar espacios duplicados
    String cleaned = text.replaceAll(RegExp(r'\s+'), ' ').trim();

    // 2. Unificar moneda cuando viene separada con espacio (ej: "$ 48.000.000", "S/ 25,507,198", "R$ 87.000.000")
    cleaned = cleaned.replaceAllMapped(
      RegExp(r'^(R\$|\$|S\/|US\$)\s+(\d+)'),
      (match) => "${match.group(1)}${match.group(2)}",
    );

    // 3. Detectar si contiene sufijos de magnitud (ej: "$55.200 millones", "$10 Million", "$220,000,000 MXN", "59 Millones de Euros")
    final regexMagnitud = RegExp(
      r'^((?:R\$|\$|S\/|US\$)?\s*[\d\.,]+(?:\s*€)?)\s+(millones(?:\s+de\s+euros|\s+cop)?|million|millón|mxn|mdp|millões|\/.*|€\/.*)$',
      caseSensitive: false,
    );

    final matchMag = regexMagnitud.firstMatch(cleaned);
    if (matchMag != null) {
      String label = matchMag.group(2)?.trim() ?? "";
      if (label.toLowerCase() == "millones" && defaultCurrency.isNotEmpty) {
        label = "millones $defaultCurrency";
      } else if (label.toLowerCase() == "million" && defaultCurrency.isNotEmpty) {
        label = "Million $defaultCurrency";
      }
      return {
        "value": matchMag.group(1)?.trim() ?? cleaned,
        "label": label,
      };
    }

    // 4. Si es un monto con moneda (ej: "$48.000.000", "R$87.000.000,00", "14.500.000 €", "S/25,507,198")
    // Se adjunta la moneda oficial del país si la etiqueta quedó vacía
    return {
      "value": cleaned,
      "label": defaultCurrency,
    };
  }
}
